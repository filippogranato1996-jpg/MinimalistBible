"""Wandelt Design-Pixel (Referenzbreite 369) in skalierende calc()-Ausdrücke um.
Aufruf: python3 build_css.py   ->  schreibt app/src/main/assets/app.css"""
import re, os
here = os.path.dirname(os.path.abspath(__file__))
src = open(os.path.join(here, "app.src.css"), encoding="utf-8").read()

def conv(m):
    n = float(m.group(1))
    if n == 0:
        return "0"
    s = ("%g" % n)
    return "calc(%s * var(--u))" % s

# Nur Zahlen mit px, nicht innerhalb von url(...)
out = []
for part in re.split(r"(url\([^)]*\))", src):
    if part.startswith("url("):
        out.append(part)
    else:
        out.append(re.sub(r"(-?\d*\.?\d+)px", conv, part))
css = "".join(out)
# --u selbst darf nicht rekursiv sein
css = css.replace("--u:calc(100vw / 369)", "--u:calc(100vw / 369)")
dst = os.path.join(here, "..", "app", "src", "main", "assets", "app.css")
open(dst, "w", encoding="utf-8").write(css)
print("app.css geschrieben:", len(css) // 1024, "KB")
