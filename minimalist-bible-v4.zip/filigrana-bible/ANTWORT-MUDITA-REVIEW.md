# Reply to the Mudita review (version 23)

Medium: (1) About / Licences screen with SIL OFL 1.1 text, font copyright notices and the source/status of each translation; licence files also in the APK (assets/licenses). (2) Privacy policy and Terms of Use in the profile menu with publisher details (Filippo Granato, Herrenberg, Germany, Granato.filippo@icloud.com); allowBackup=false; "Delete all data". (3) Messages stay 4.5 s; import errors appear as a dialog with OK; the file format is described before the import.
Low: (4) default name "Du". (5) UI follows the system language (English/German; switchable in the profile menu). (6) Reading position is kept when switching modes. (7) microphone icon removed; sharing no longer copies automatically; clearing history asks first; empty collection name becomes "Sammlung"; "1 Vers"; profile line fixed; closing quotes; Georgia removed. (9) Pure black/white design, no grey fills, dialogs without dimming and with a thick border, labels 14 px in black.
Open: (8) WebView accessibility not yet tested with TalkBack; the illustration still has grey halftones.
New: welcome page with tips, "What's new" screen, CHANGELOG.md.
