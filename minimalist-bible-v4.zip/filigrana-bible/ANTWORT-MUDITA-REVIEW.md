# Version 22 – Antwort auf das Mudita-Review

Mittel: 1 About/Lizenzen (OFL-Text, Schrift-Copyrights, Bibelquellen, LICENSES in assets/licenses), 2 Datenschutz + Nutzungsbedingungen im Profilmenü, allowBackup=false, Button "Alle Daten löschen", 3 Meldungen 4,5 s, Importfehler als Dialog mit OK, Formatbeschreibung vor dem Import.
Niedrig: 4 Standardname "Du", 6 Position beim Moduswechsel bleibt, 7 Mikrofon entfernt, Teilen kopiert nicht mehr automatisch, Verlauf leeren fragt nach, leere Sammlung heißt "Sammlung", "1 Vers", Profilzeile umbricht nicht mehr, Anführungszeichen „…“, Georgia entfernt (schon seit v17), 9 weiß ohne Grau, Dialoge ohne Abdunkeln mit dicker Umrandung, Labels 14 px in Schwarz.
Offen: 5 Oberfläche nur Deutsch (Hinweis in der Store-Beschreibung), 8 Barrierefreiheit (WebView), Illustration mit Graustufen.
