# Changelog – Minimalist Bible

## Version 23 (versionCode 23)
**EN:** System language support (English/German, switchable in the profile menu). Welcome page with the most important tips (including: press and hold a book or chapter in the book picker to add it to a collection as a reading plan). "What's new", "About / Licences", "Privacy" and "Terms of Use" screens in the profile menu. Publisher details added.
**DE:** Systemsprache (Englisch/Deutsch, im Profilmenü umschaltbar). Willkommensseite mit den wichtigsten Tipps (u. a.: Buch oder Kapitel in der Bücherauswahl gedrückt halten, um es als Bibelleseplan zu einer Sammlung hinzuzufügen). Seiten „Neuigkeiten“, „Über / Lizenzen“, „Datenschutz“ und „Nutzungsbedingungen“ im Profilmenü. Herausgeberangaben ergänzt.

## Version 22
EN: Review fixes: licence information (SIL OFL, font notices, Bible sources), privacy policy and terms, Android backup disabled, "Delete all data", messages stay 4.5 s, import errors as dialog with OK, format description before import, default name "Du", reading position kept when switching modes, microphone icon removed, sharing no longer copies automatically, "Clear history" asks first, pure black/white e-ink design without grey fills or dimming, bigger labels.
DE: Review-Korrekturen (siehe oben).

## Version 21
EN: Select and copy text in page mode (long press). Page counter across the whole book when the chapter heading is off.
DE: Text im Blättermodus markieren und kopieren. Seitenzähler über das ganze Buch, wenn die Kapitelüberschrift aus ist.

## Version 20
EN: Calmer page turn in page mode (single refresh instead of a wipe). DE: Ruhigerer Seitenwechsel.

## Version 19
EN: Progress of a reading plan only changes when reading through the collection. DE: Fortschritt ändert sich nur noch über die Sammlung.

## Version 18
EN: The normal reader and the collection reader keep separate reading mode, font and size. DE: Getrennte Reader-Einstellungen.

## Version 17
EN: Only three fonts (Source Serif, Lora, Inter); dark mode, verse numbers and chapter heading as icons in the aA menu. DE: Drei Schriftarten, Icons im aA-Menü.

## Version 16
EN: Page mode (full screen, tap or swipe to turn pages, menu on tap in the middle), dark mode in the reader, swipe to next chapter in scroll mode, running text in collections with optional verse numbers/chapter heading. DE: Blättermodus, Dunkelmodus im Reader, Wischen zum nächsten Kapitel, Fließtext in Sammlungen.

## Version 15
EN: Collections of single verses look like "Saved" and can be flipped through; reading plans keep you inside the chosen books/chapters. DE: Sammlungen wie „Gemerkt“, Durchblättern, kein Springen in der Bibel.

## Version 14
EN: Reading plan: long-press a book or chapter in the book picker to add it to a collection; cards with progress bar; continue where you stopped; collections without notes. DE: Bibelleseplan.

## Version 4 – 13
EN: Tabs Start / Saved / Collections, three translations (Schlachter 1951, Berean Standard Bible, Riveduta), verse of the day and random verse (509 well-known verses), share verse as image (copy / gallery / share), focused mode with volume keys, scrubber, search with suggestions, quick translation switch, dark mode, multi-verse selection, import your own Bible, signed release build.
DE: Tabs Start / Gemerkt / Sammlung, drei Übersetzungen, Vers des Tages, Teilen als Bild, Focused Mode, Scrubber, Suche mit Vorschlägen, Dunkelmodus, Mehrfachauswahl, Bibel importieren.
