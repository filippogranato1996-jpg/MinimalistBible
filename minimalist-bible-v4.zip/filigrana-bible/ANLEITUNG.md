# Minimalist Bible – APK selbst bauen (GitHub, kostenlos)

Die App läuft komplett offline (keine Internet-Berechtigung). Die APK-Datei wird
kostenlos von GitHub für dich gebaut – du brauchst keinen Computer mit Android Studio.

## 1. Einmalig: GitHub-Konto und Repository
1. Auf github.com ein kostenloses Konto anlegen (falls noch nicht vorhanden).
2. Oben rechts **+ → New repository**. Name z. B. `minimalist-bible`, **Private** wählen, **Create repository**.

## 2. Projekt hochladen
1. ZIP-Datei auf dem Computer **entpacken**.
2. Im Repository: **Add file → Upload files**.
3. Den **Inhalt** des entpackten Ordners (Ordner `app`, `gradle.properties`, `build.gradle`, `settings.gradle` …) ins Browserfenster ziehen – nicht den äußeren Ordner selbst.
   Tipp: Wenn die Bibel-Dateien (29 MB) das Hochladen bremsen, in zwei Schritten hochladen (erst alles außer `app/src/main/assets/bibles`, dann diesen Ordner).
4. Unten **Commit changes** klicken.

## 3. Build-Anleitung (Workflow) anlegen
Der versteckte Ordner `.github` lässt sich im Browser nicht hochladen, deshalb von Hand:
1. **Add file → Create new file**.
2. Im Namensfeld exakt eingeben: `.github/workflows/build.yml`
   (beim Tippen von `/` werden automatisch Ordner angelegt).
3. Den Inhalt der Datei `build-workflow.yml` aus dem ZIP hineinkopieren.
4. **Commit changes**.

## 4. APK herunterladen
1. Oben auf den Reiter **Actions** gehen.
2. Der Lauf „Build APK" startet automatisch: gelb = läuft (ca. 3–6 Min.), grün = fertig, rot = Fehler.
3. Auf den grünen Lauf klicken, ganz unten bei **Artifacts** auf **MinimalistBible-APK** klicken → ZIP wird geladen.
4. ZIP entpacken → darin liegt `app-debug.apk`.

## 5. Auf das Mudita Kompakt installieren
1. Mudita per USB-Kabel an den Computer anschließen (Dateiübertragung) und `app-debug.apk` in den Ordner „Download" kopieren.
2. Am Gerät mit einem Dateimanager die APK antippen und **Installieren** wählen (ggf. „Aus dieser Quelle erlauben" aktivieren).
3. Die App heißt **Minimalist Bible**.

## Neue Version einspielen
Dank des festen Signaturschlüssels im Projekt lässt sich eine neue APK **ab Version 4 einfach über die alte installieren** – deine Daten (Gemerkt, Sammlungen, Notizen) bleiben erhalten.
**Einmalig beim Wechsel auf Version 4:** Die alte App (frühere Version) vorher deinstallieren, weil sie mit einem anderen Schlüssel gebaut wurde. Dabei gehen die alten Daten verloren.

Neue Version hochladen: Im Repository die alte `filigrana-bible-android.zip` löschen (Datei öffnen → ⋯ → Delete file), die neue ZIP ungeöffnet hochladen, Commit. Der Build startet von selbst.

## Wenn etwas schiefgeht
- **Roter Lauf, „settings.gradle nicht gefunden"**: Die ZIP liegt nicht im Hauptordner des Repositorys oder fehlt.
- **Roter Lauf, „Bibel fehlt"**: Die ZIP wurde beim Hochladen beschädigt – erneut hochladen.
- **Kein „Artifacts"-Bereich**: Lauf ist noch gelb – warten.
- **Roter Lauf anderer Art**: Lauf anklicken, die rot markierte Zeile als Screenshot schicken.
- **Installation blockiert**: In den Einstellungen die Installation aus unbekannten Quellen für den Dateimanager erlauben.
- **„App nicht installiert"**: Die alte App mit anderem Schlüssel ist noch drauf – vorher deinstallieren.

## Bedienung
- **Start**: nach links wischen öffnet die Bibel. Suchleiste: 1. Tippen = Verlauf, 2. Tippen = Tastatur; beim Tippen erscheinen Vorschläge (z. B. „Joh", „Johannes 3:16"). Ein weiteres Tippen auf „Start" in der unteren Leiste öffnet direkt die Tastatur.
- **Bibel (Fokusmodus)**: Tippen rechts = nächster Vers, links = vorheriger Vers; ebenso die Lautstärketasten (leiser = weiter, lauter = zurück). „aA" öffnet Schrift, Größe, Fokusmodus und den **schnellen Übersetzungswechsel**.
- **Merken**: Der gemerkte Vers bekommt einen schmalen Rahmen und erscheint im Tab **Gemerkt** (Herz).
- **Gemerkt**: Tippen öffnet den Vers als Karte, langes Drücken zeigt das Menü: In der Bibel öffnen, Oben anheften / Lösen, Zur Sammlung hinzufügen, Vers entfernen.
- **Sammlung**: Themensammlungen mit Titel, Beschreibung, Notizen und Versen. Im Leser über „Zur Sammlung" Verse hinzufügen.
- Vers des Tages und Zufallsvers laufen offline aus eingebauten Daten.

## Enthaltene Bibeln
Schlachter 1951, Riveduta 1990 und Berean Standard Bible (Englisch), jeweils komplett.
Hinweis: Schlachter 1951 und Riveduta 1990 sind urheberrechtlich geschützt (kostenlose, nicht-kommerzielle Verbreitung) – nur privat nutzen.
