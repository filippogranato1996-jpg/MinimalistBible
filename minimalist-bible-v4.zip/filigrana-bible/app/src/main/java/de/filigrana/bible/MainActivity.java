package de.filigrana.bible;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

public class MainActivity extends Activity {

    private static final int REQ_FILE = 1;

    private WebView web;
    private ValueCallback<Uri[]> chooserCallback;
    private volatile boolean volumeNav = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setTextZoom(100);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setLongClickable(false);
        web.setHapticFeedbackEnabled(false);

        web.addJavascriptInterface(new Bridge(), "Android");

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (chooserCallback != null) {
                    chooserCallback.onReceiveValue(null);
                }
                chooserCallback = callback;
                try {
                    startActivityForResult(params.createIntent(), REQ_FILE);
                } catch (Exception e) {
                    chooserCallback = null;
                    return false;
                }
                return true;
            }
        });

        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_FILE) {
            if (chooserCallback != null) {
                chooserCallback.onReceiveValue(
                        WebChromeClient.FileChooserParams.parseResult(resultCode, data));
                chooserCallback = null;
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    /** Lautstärketasten blättern im Leser: leiser = nächster Vers, lauter = vorheriger Vers. */
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (volumeNav && (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN || keyCode == KeyEvent.KEYCODE_VOLUME_UP)) {
            final int dir = keyCode == KeyEvent.KEYCODE_VOLUME_DOWN ? 1 : -1;
            web.evaluateJavascript("window.appVolume ? window.appVolume(" + dir + ") : false", null);
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        if (volumeNav && (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN || keyCode == KeyEvent.KEYCODE_VOLUME_UP)) {
            return true;
        }
        return super.onKeyUp(keyCode, event);
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("window.appBack ? window.appBack() : false", value -> {
            if (!"true".equals(value)) {
                finish();
            }
        });
    }

    private static String safe(String id) {
        return id.replaceAll("[^a-zA-Z0-9_]", "");
    }

    private boolean hasAsset(String id) {
        try (InputStream in = getAssets().open("bibles/" + safe(id) + ".json")) {
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private File bibleFile(String id) {
        File dir = new File(getFilesDir(), "bibles");
        //noinspection ResultOfMethodCallIgnored
        dir.mkdirs();
        return new File(dir, safe(id) + ".json");
    }

    /** Brücke zwischen der Web-Oberfläche und dem Gerätespeicher (importierte Bibeln). */
    public class Bridge {
        @JavascriptInterface
        public void setVolumeNav(boolean on) {
            volumeNav = on;
        }

        @JavascriptInterface
        public boolean hasBible(String id) {
            return bibleFile(id).exists() || hasAsset(id);
        }

        @JavascriptInterface
        public String readBible(String id) {
            try {
                File f = bibleFile(id);
                if (f.exists()) {
                    return new String(Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8);
                }
                try (InputStream in = getAssets().open("bibles/" + safe(id) + ".json")) {
                    ByteArrayOutputStream out = new ByteArrayOutputStream();
                    byte[] buf = new byte[65536];
                    int n;
                    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                    return new String(out.toByteArray(), StandardCharsets.UTF_8);
                }
            } catch (Exception e) {
                return "";
            }
        }

        @JavascriptInterface
        public boolean saveBible(String id, String json) {
            try (FileOutputStream out = new FileOutputStream(bibleFile(id))) {
                out.write(json.getBytes(StandardCharsets.UTF_8));
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public void deleteBible(String id) {
            //noinspection ResultOfMethodCallIgnored
            bibleFile(id).delete();
        }
    }
}
