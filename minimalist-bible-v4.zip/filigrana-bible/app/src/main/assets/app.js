(function () {
'use strict';

/* ---------- Stammdaten ---------- */
var DE = ['1. Mose','2. Mose','3. Mose','4. Mose','5. Mose','Josua','Richter','Ruth','1. Samuel','2. Samuel','1. Könige','2. Könige','1. Chronik','2. Chronik','Esra','Nehemia','Esther','Hiob','Psalm','Sprüche','Prediger','Hoheslied','Jesaja','Jeremia','Klagelieder','Hesekiel','Daniel','Hosea','Joel','Amos','Obadja','Jona','Micha','Nahum','Habakuk','Zephanja','Haggai','Sacharja','Maleachi','Matthäus','Markus','Lukas','Johannes','Apostelgeschichte','Römer','1. Korinther','2. Korinther','Galater','Epheser','Philipper','Kolosser','1. Thessalonicher','2. Thessalonicher','1. Timotheus','2. Timotheus','Titus','Philemon','Hebräer','Jakobus','1. Petrus','2. Petrus','1. Johannes','2. Johannes','3. Johannes','Judas','Offenbarung'];
var EN = ['Genesis','Exodus','Leviticus','Numbers','Deuteronomy','Joshua','Judges','Ruth','1 Samuel','2 Samuel','1 Kings','2 Kings','1 Chronicles','2 Chronicles','Ezra','Nehemiah','Esther','Job','Psalms','Proverbs','Ecclesiastes','Song of Solomon','Isaiah','Jeremiah','Lamentations','Ezekiel','Daniel','Hosea','Joel','Amos','Obadiah','Jonah','Micah','Nahum','Habakkuk','Zephaniah','Haggai','Zechariah','Malachi','Matthew','Mark','Luke','John','Acts','Romans','1 Corinthians','2 Corinthians','Galatians','Ephesians','Philippians','Colossians','1 Thessalonians','2 Thessalonians','1 Timothy','2 Timothy','Titus','Philemon','Hebrews','James','1 Peter','2 Peter','1 John','2 John','3 John','Jude','Revelation'];
var IT = ['Genesi','Esodo','Levitico','Numeri','Deuteronomio','Giosuè','Giudici','Rut','1 Samuele','2 Samuele','1 Re','2 Re','1 Cronache','2 Cronache','Esdra','Neemia','Ester','Giobbe','Salmi','Proverbi','Ecclesiaste','Cantico dei Cantici','Isaia','Geremia','Lamentazioni','Ezechiele','Daniele','Osea','Gioele','Amos','Abdia','Giona','Michea','Naum','Abacuc','Sofonia','Aggeo','Zaccaria','Malachia','Matteo','Marco','Luca','Giovanni','Atti','Romani','1 Corinzi','2 Corinzi','Galati','Efesini','Filippesi','Colossesi','1 Tessalonicesi','2 Tessalonicesi','1 Timoteo','2 Timoteo','Tito','Filemone','Ebrei','Giacomo','1 Pietro','2 Pietro','1 Giovanni','2 Giovanni','3 Giovanni','Giuda','Apocalisse'];
var CH = [50,40,27,36,34,24,21,4,31,24,22,25,29,36,10,13,10,42,150,31,12,8,66,52,5,48,12,14,3,9,1,4,7,3,3,3,2,14,4,28,16,24,21,28,16,16,13,6,6,4,4,5,3,6,4,3,1,13,5,5,3,5,1,1,1,22];
var SLOTS = [
  {id:'schlachter', name:'Schlachter 1951', short:'Schlachter', lang:'de'},
  {id:'bsb', name:'Berean Standard Bible', short:'BSB', lang:'en'},
  {id:'riveduta', name:'Riveduta 1990', short:'Riveduta', lang:'it'}
];
var GROUPS = [['de','DEUTSCH'],['en','ENGLISH'],['it','ITALIANO']];
var FONTS = [
  {id:'sourceserif', name:'Source Serif', css:"'Source Serif 4',Georgia,serif"},
  {id:'lora', name:'Lora', css:"'Lora',Georgia,serif"},
  {id:'inter', name:'Inter', css:"'Inter',Arial,sans-serif"}
];
var SIZES = {S:20, M:24, L:28, XL:32};
var MONTHS = ['JAN.','FEB.','MÄR.','APR.','MAI','JUN.','JUL.','AUG.','SEP.','OKT.','NOV.','DEZ.'];

/* ---------- Helfer ---------- */
function $(s) { return document.querySelector(s); }
function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) {
    return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];
  });
}
/* Lucide-ähnliche Symbole (24er-Raster) */
var ICON = {
  home:['M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8','M3 10a2 2 0 0 1 .709-1.528l7-5.999a2 2 0 0 1 2.582 0l7 5.999A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z'],
  pin:['M12 17v5','M9 10.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V7a1 1 0 0 1 1-1 2 2 0 0 0 0-4H8a2 2 0 0 0 0 4 1 1 0 0 1 1 1z'],
  book:['M12 7v14','M3 18a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h5a4 4 0 0 1 4 4 4 4 0 0 1 4-4h5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-6a3 3 0 0 0-3 3 3 3 0 0 0-3-3z'],
  bookm:['M10 2v8l3-3 3 3V2','M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20'],
  search:['M21 21l-4.34-4.34','M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16z'],
  mic:['M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z','M19 10v2a7 7 0 0 1-14 0v-2','M12 19v3'],
  shuffle:['M2 18h1.4c1.3 0 2.5-.6 3.3-1.7l6.1-8.6c.7-1.1 2-1.7 3.3-1.7H22','m18 2 4 4-4 4','M2 6h1.9c1.5 0 2.9.9 3.6 2.2','M22 18h-5.9c-1.3 0-2.6-.7-3.3-1.8l-.5-.8','m18 14 4 4-4 4'],
  x:['M18 6 6 18','m6 6 12 12'],
  down:['m6 9 6 6 6-6'],
  left:['m15 18-6-6 6-6'],
  right:['m9 18 6-6-6-6'],
  comment:['M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z'],
  heart:['M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z'],
  plus:['M5 12h14','M12 5v14'],
  trash:['M3 6h18','M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6','M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2','M10 11v6','M14 11v6'],
  play:['m6 3 14 9-14 9z'],
  folder:['M12 10v6','M9 13h6','M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z'],
  history:['M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8','M3 3v5h5','M12 7v5l4 2'],
  check:['M20 6 9 17l-5-5'],
  camera:['M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z','M12 16a3 3 0 1 0 0-6 3 3 0 0 0 0 6z'],
  pencil:['M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z'],
  share:['M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8','m16 6-4-4-4 4','M12 2v13'],
  copy:['M10 8h10a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H10a2 2 0 0 1-2-2V10a2 2 0 0 1 2-2z','M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2'],
  down2:['M12 15V3','m7 10 5 5 5-5','M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4'],
  moon:['M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z'],
  moon:['M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z'],
  hash:['M4 9h16','M4 15h16','M10 3 8 21','M16 3l-2 18'],
  upload:['M12 3v12','m17 8-5-5-5 5','M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4']
};
function ic(n, cls, fill) {
  return '<svg class="ic ' + (cls || '') + '" viewBox="0 0 24 24"' + (fill ? ' style="fill:currentColor"' : '') + '>' +
    ICON[n].map(function (d) { return '<path d="' + d + '"/>'; }).join('') + '</svg>';
}
function rnd(n) { return Math.floor(Math.random() * n); }
function toast(msg) {
  var t = $('#toast');
  t.textContent = msg; t.hidden = false;
  clearTimeout(toast.t);
  toast.t = setTimeout(function () { t.hidden = true; }, 4500);
}
function fmtDate(ts) {
  var d = new Date(ts);
  return d.getDate() + '. ' + MONTHS[d.getMonth()];
}

/* ---------- Zustand ---------- */
function defaults() {
  return { bible:'schlachter', last:{b:42, c:3}, history:[], pins:[], marks:[], notes:{},
           andachten:[], font:'sourceserif', size:'M', focused:true, mode:'focus', showVn:true, showCh:true, dark:false, name:'Du', img:'' };
}
var S = (function () {
  var s = null;
  try { s = JSON.parse(localStorage.getItem('fb')); } catch (e) {}
  s = (s && typeof s === 'object') ? Object.assign(defaults(), s) : defaults();
  if (!FONTS.some(function (f) { return f.id === s.font; })) s.font = 'sourceserif';
  if (!SIZES[s.size]) s.size = 'M';
  if (['focus', 'scroll', 'page'].indexOf(s.mode) < 0 || (s.mode === 'focus' && s.focused === false)) s.mode = s.focused === false ? 'scroll' : 'focus';
  s.focused = s.mode === 'focus';
  s.rc = s.rc || {mode:s.mode, font:s.font, size:s.size};
  s.sc = s.sc || {mode:s.mode, font:s.font, size:s.size};
  var MAP = {luther1912:'schlachter', elberfelder:'schlachter', kjv:'bsb', diodati:'riveduta'};
  var mb = function (id) { return MAP[id] || id; };
  s.bible = mb(s.bible);
  if (!SLOTS.some(function (x) { return x.id === s.bible; })) s.bible = 'schlachter';
  ['history', 'marks', 'pins'].forEach(function (k) { (s[k] || []).forEach(function (x) { if (x.bid) x.bid = mb(x.bid); }); });
  (s.andachten || []).forEach(function (a) { a.verses = a.verses || []; a.plan = a.plan || []; a.verses.forEach(function (v) { if (v.bid) v.bid = mb(v.bid); }); });
  if (s.pins && s.pins.length) {
    s.pins.forEach(function (p) { p.pin = true; });
    s.marks = s.pins.concat(s.marks.filter(function (m) {
      return !s.pins.some(function (p) { return p.b === m.b && p.c === m.c && p.v === m.v && p.bid === m.bid; });
    }));
  }
  s.pins = [];
  return s;
})();
function save() { try { localStorage.setItem('fb', JSON.stringify(S)); } catch (e) {} }

function slot(id) {
  for (var i = 0; i < SLOTS.length; i++) if (SLOTS[i].id === id) return SLOTS[i];
  return SLOTS[0];
}
function lang(id) { return slot(id || S.bible).lang; }
function bname(b, bid) { var l = lang(bid); return (l === 'de' ? DE : l === 'it' ? IT : EN)[b]; }
function fmtRef(b, c, v, bid) {
  return bname(b, bid) + ' ' + c + (v ? (lang(bid) === 'de' ? ',' : ':') + v : '');
}
function nkey(b, c, v) { return b + '.' + c + '.' + v; }

/* ---------- Bibeltexte ---------- */
var cache = {};
function toDense(raw) {
  if (Array.isArray(raw)) return raw.map(function (x) { return x.chapters || x; });
  if (raw && raw.books) return raw.books.map(function (x) { return x.chapters || x; });
  return null;
}
function fromSample(list) {
  var bk = [];
  list.forEach(function (r) {
    bk[r[0]] = bk[r[0]] || [];
    bk[r[0]][r[1] - 1] = bk[r[0]][r[1] - 1] || [];
    bk[r[0]][r[1] - 1][r[2] - 1] = r[3];
  });
  return bk;
}
function bible(id) {
  if (id in cache) return cache[id];
  var d = null;
  try {
    if (window.Android && Android.hasBible(id)) {
      d = toDense(JSON.parse(String(Android.readBible(id)).replace(/^﻿/, '')));
    }
  } catch (e) { d = null; }
  if (!d && window.SAMPLE && SAMPLE[id]) d = fromSample(SAMPLE[id]);
  cache[id] = d;
  return d;
}
function isFull(id) {
  var d = bible(id);
  return !!(d && d.length >= 66 && d[0] && d[65]);
}
function nch(b, bid) {
  var d = bible(bid || S.bible);
  return d && d[b] && d[b].length ? d[b].length : CH[b];
}
function totalCh() { var t = 0; for (var b = 0; b < 66; b++) t += nch(b); return t; }
function chapter(id, b, c) {
  var d = bible(id), ch = d && d[b] && d[b][c - 1], out = [];
  if (!ch) return out;
  for (var i = 0; i < ch.length; i++) {
    if (ch[i] != null && ch[i] !== '') out.push({n: i + 1, t: String(ch[i])});
  }
  return out;
}
function verseText(id, b, c, v) {
  var d = bible(id), t = d && d[b] && d[b][c - 1] && d[b][c - 1][v - 1];
  return t ? String(t) : null;
}
function anyText(b, c, v, pref) {
  var first = pref || S.bible;
  var order = [first];
  SLOTS.forEach(function (s) { if (s.lang === lang(first) && order.indexOf(s.id) < 0) order.push(s.id); });
  SLOTS.forEach(function (s) { if (order.indexOf(s.id) < 0) order.push(s.id); });
  for (var i = 0; i < order.length; i++) {
    var t = verseText(order[i], b, c, v);
    if (t) return {t: t, bid: order[i]};
  }
  return null;
}
function pool() {
  var p = REFS.filter(function (r) { return verseText(S.bible, r[0], r[1], r[2]); });
  if (p.length) return p;
  p = REFS.filter(function (r) { return anyText(r[0], r[1], r[2]); });
  return p.length ? p : REFS;
}
function votdRef() {
  var p = pool(), n = new Date();
  var day = Math.floor(Date.UTC(n.getFullYear(), n.getMonth(), n.getDate()) / 864e5);
  var r = p[day % p.length];
  return {kind:'votd', b:r[0], c:r[1], v:r[2]};
}
function randomRef(prev) {
  var p = pool(), r;
  for (var t = 0; t < 12; t++) {
    r = p[rnd(p.length)];
    if (!prev || p.length < 2 || r[0] !== prev.b || r[1] !== prev.c || r[2] !== prev.v) break;
  }
  return {kind:'random', b:r[0], c:r[1], v:r[2]};
}

/* ---------- Navigation ---------- */
var tab = 'start', startPanel = null, card = null, searchVal = '', searchActive = false;
var stack = [];
var bodyScroll = 0, lastRandMark = -1;
var baseH = window.innerHeight, kbOpen = false;
function updateTyping() { document.body.classList.toggle('typing', !!(searchActive || kbOpen)); }
function blurSearch() {
  var ae = document.activeElement;
  if (ae && ae !== document.body && ae.blur) ae.blur();
  var q = $('#q'); if (q) q.readOnly = true;
  searchActive = false;
  try { if (window.Android && Android.hideKeyboard) Android.hideKeyboard(); } catch (e) {}
  updateTyping();
}
window.addEventListener('resize', function () {
  if (window.innerHeight > baseH) baseH = window.innerHeight;
  var was = kbOpen;
  kbOpen = window.innerHeight < baseH * 0.82;
  if (was && !kbOpen && searchActive) { var ae = document.activeElement; if (ae && ae.id === 'q') ae.blur(); }
  updateTyping();
});
var fsOn = null;
function fsSync() {
  var on = topOv() === 'reader' && S.mode === 'page';
  if (on === fsOn) return;
  fsOn = on;
  try { if (window.Android && Android.setFullscreen) Android.setFullscreen(on); } catch (e) {}
}
function syncVol() {
  var t = topOv();
  fsSync();
  try { if (window.Android && Android.setVolumeNav) Android.setVolumeNav(t === 'reader' || t === 'stepper'); } catch (e) {}
}
function showOv(name) {
  var el = $('#' + name);
  el.hidden = false;
  var i = stack.indexOf(name); if (i >= 0) stack.splice(i, 1);
  stack.push(name);
  el.style.zIndex = 10 + stack.length;
  syncVol();
}
function loadCfg(scoped) {
  var c = scoped ? S.sc : S.rc;
  S.mode = c.mode; S.font = c.font; S.size = c.size; S.focused = c.mode === 'focus';
  applyReadStyle();
}
function saveCfg() {
  var c = R && R.scope ? S.sc : S.rc;
  c.mode = S.mode; c.font = S.font; c.size = S.size;
}
function hideOv(name) {
  if (name === 'reader' && R && R.scope) loadCfg(false);
  $('#' + name).hidden = true;
  var i = stack.indexOf(name); if (i >= 0) stack.splice(i, 1);
  syncVol();
}
function topOv() { return stack[stack.length - 1]; }

function modal(html, transparent) {
  var m = $('#modal');
  m.innerHTML = '<div class="mbg" data-a="closeModal"' + (transparent ? ' style="background:transparent"' : '') + '></div>' + html;
  m.hidden = false;
}
function closeModal() { var m = $('#modal'); m.hidden = true; m.innerHTML = ''; }

/* ---------- Hauptansicht ---------- */
function setTab(t) { if (t !== tab) bodyScroll = 0; tab = t; card = null; startPanel = null; searchActive = false; renderMain(); }

document.addEventListener('DOMContentLoaded', function () {
  var bd = $('#body'); if (bd) bd.addEventListener('scroll', function () { if (!card) bodyScroll = bd.scrollTop; });
});
function renderMain() {
  var av = $('#avatar');
  if (S.img) av.innerHTML = '<img alt="" src="' + esc(S.img) + '">';
  else {
    var ini = S.name.split(/\s+/).map(function (w) { return w.charAt(0); }).join('').slice(0, 2).toUpperCase();
    av.textContent = ini || '?';
  }
  var b = $('#body');
  b.innerHTML = (tab === 'start' ? viewStart() : tab === 'marks' ? viewMarks() : viewAndachten()) + (card ? cardHtml(card) : '');
  b.style.overflowY = card ? 'hidden' : 'auto';
  b.scrollTop = card ? 0 : bodyScroll;
  var tabs = [['start','home','Start'],['marks','heart','Gemerkt'],['andachten','book','Sammlung']];
  if (tab === 'start' && !card) applySugg();
  updateTyping();
  $('#nav').innerHTML = tabs.map(function (t) {
    return '<button data-a="tab" data-t="' + t[0] + '" class="' + (tab === t[0] ? 'on' : '') + '">' + ic(t[1]) + '<span class="cap">' + t[2] + '</span></button>';
  }).join('');
}

function viewStart() {
  var h = '<div class="start' + (startPanel === 'history' ? ' h' : '') + '"><div class="art"></div>' +
    '<div class="trow"><span class="lbl t1">Übersetzung</span><button class="sel" data-a="trans">' +
    esc(slot(S.bible).name) + ic('down') + '</button></div>';
  h += '<div class="srow"><div class="search">' + ic('search') +
    '<input id="q" type="text" value="' + esc(searchVal) + '" placeholder="Psalm 23, Römer 8 …" autocomplete="off" enterkeyhint="search"' +
    (searchActive ? '' : ' readonly') + '>' +
    '<span class="qb" id="qbtn" data-a="clearQ">' + (searchVal ? ic('x', 'mic') : '') + '</span></div>' +
    '<button class="sq" data-a="random" aria-label="Zufälliger Vers">' + ic('shuffle') + '</button></div>' +
    '<div class="hist sugg" id="sugg" style="display:none"></div><div id="below">';
  if (startPanel === 'history') {
    h += '<div class="hist"><div class="hh"><span class="lbl">' + ic('history') + 'Zuletzt gelesen</span>' +
      '<button data-a="clearHist">' + ic('trash') + 'Leeren</button></div>';
    if (!S.history.length) h += '<div class="none">Noch nichts gelesen.</div>';
    S.history.forEach(function (x) {
      h += '<button class="row" data-a="openCh" data-id="' + (x.bid || '') + '" data-b="' + x.b + '" data-c="' + x.c + '"><b>' +
        esc(bname(x.b, x.bid) + ' ' + x.c) + '</b><small>' + fmtDate(x.t) + '</small>' + ic('book') + '</button>';
    });
    h += '</div>';
  } else {
    var r = votdRef();
    h += '<button class="votd" data-a="votd"><span class="lbl">Vers des Tages</span><b>' + esc(fmtRef(r.b, r.c, r.v)) + '</b></button>';
  }
  h += '</div></div>';
  if (startPanel === 'trans') {
    h += '<div class="dd">';
    GROUPS.forEach(function (g) {
      h += '<span class="lbl">' + g[1] + '</span><div class="grp">';
      SLOTS.filter(function (s) { return s.lang === g[0]; }).forEach(function (s) {
        h += '<button class="opt ' + (s.id === S.bible ? 'on' : '') + '" data-a="setBible" data-id="' + s.id + '">' +
          '<span>' + esc(s.name) + '</span>' + (s.id === S.bible ? ic('check') : '') + '</button>';
      });
      h += '</div>';
    });
    h += '</div>';
  }
  return h;
}

/* Karte: kind = votd | random | pins | marks */
function cardHtml(r) {
  var got = anyText(r.b, r.c, r.v, r.bid), ref = fmtRef(r.b, r.c, r.v, r.bid);
  var body = got
    ? '„' + esc(got.t) + '“' + (got.bid !== S.bible ? '<div class="src">' + esc(slot(got.bid).name) + '</div>' : '')
    : '<span class="muted" style="font-family:var(--sans);font-size:calc(14 * var(--u))">Der Text ist in dieser Übersetzung nicht eingebaut. Wechsle die Übersetzung auf der Startseite.</span>';
  var lbl = r.kind === 'votd' ? 'Vers des Tages' : r.kind === 'random' ? 'Zufälliger Vers' : r.kind === 'marks' ? 'Gemerkt' : 'Angepinnt';
  var cls = r.kind === 'votd' ? 'vot' : r.kind === 'random' ? 'rnd' : 'pin';
  return '<div class="card ' + cls + '"><div class="ch"><span class="lbl">' + lbl +
    '</span><button data-a="closeCard" aria-label="Schließen">' + ic('x') + '</button></div>' +
    '<div class="cb"><div class="cref">' + esc(ref) + '</div><div class="ctext">' + body + '</div></div>' +
    '<div class="cf"><button class="primary" data-a="openVerse" data-b="' + r.b + '" data-c="' + r.c + '" data-v="' + r.v + '" data-id="' + (r.bid || '') + '">' +
    ic('book') + 'In der Bibel lesen</button></div></div>';
}

function tile(i) {
  var p = S.marks[i];
  return '<button class="tile" data-a="tile" data-i="' + i + '">' + (p.pin ? ic('pin', 'tp') : '') +
    esc(fmtRef(p.b, p.c, p.v, p.bid)) + '</button>';
}
function viewMarks() {
  var h = '<div class="pins"><h2 class="ph">' + ic('heart', 'l') + 'Gemerkt</h2>' +
    (S.marks.length ? '<button class="rbtn" data-a="randomMark" aria-label="Zufälliger gemerkter Vers">' + ic('shuffle') + '</button>' : '');
  if (!S.marks.length) {
    h += '<p class="empty">Noch nichts gemerkt. Öffne einen Vers im Leser und tippe auf „Merken“. Gedrückt halten öffnet das Menü.</p>';
  } else {
    var idx = S.marks.map(function (_, i) { return i; }).sort(function (a, b) {
      return ((S.marks[b].pin ? 1 : 0) - (S.marks[a].pin ? 1 : 0)) || (a - b);
    });
    h += '<div class="grid2">' + idx.map(tile).join('') + '</div>';
  }
  return h + '<div style="height:calc(22 * var(--u))"></div></div>';
}
function planPos(it) {
  var tot = 0, pos = 0, k, vs;
  if (it.t === 'c') { tot = chapter(S.bible, it.b, it.c).length; if (it.last) pos = it.last.i + 1; }
  else {
    for (k = 1; k <= nch(it.b); k++) {
      vs = chapter(S.bible, it.b, k).length;
      if (it.last && k < it.last.c) pos += vs;
      if (it.last && k === it.last.c) pos += it.last.i + 1;
      tot += vs;
    }
  }
  return {pos:Math.min(pos, tot), tot:tot};
}
function planPct(list) {
  var p = 0, t = 0;
  list.forEach(function (it) { var x = planPos(it); p += x.pos; t += x.tot; });
  return t ? Math.round(p / t * 100) : 0;
}
function planName(it) { return it.t === 'c' ? bname(it.b) + ' ' + it.c : bname(it.b); }
function viewAndachten() {
  var h = '<div class="andachten"><div class="head"><h2 class="ph">' + ic('book', 'l') + '<span>Meine Sammlungen</span></h2>' +
    '<button class="new" data-a="newAndacht">' + ic('folder') + 'Neue Sammlung</button></div>';
  if (!S.andachten.length) {
    h += '<p class="empty">Noch keine Sammlung. Lege eine Themensammlung an, füge im Leser Verse über „Zur Sammlung“ hinzu oder halte in der Bücherauswahl ein Buch oder Kapitel gedrückt (Bibelleseplan).</p>';
  } else {
    h += '<div class="grid2">' + S.andachten.map(function (a) {
      var pl = a.plan || [], sub, bar = '';
      if (pl.length) {
        var pc = planPct(pl);
        sub = (pl.length === 1 ? planName(pl[0]) : pl.length + ' Lesungen') + ' · ' + pc + ' %';
        bar = '<span class="pbar"><i style="width:' + pc + '%"></i></span>';
      } else sub = a.verses.length === 1 ? '1 Vers' : a.verses.length + ' Verse';
      return '<button class="acard" data-a="andachtOpen" data-id="' + a.id + '">' + ic(pl.length ? 'bookm' : 'book') +
        '<b>' + esc(a.title || 'Ohne Titel') + '</b><small>' + esc(sub) + '</small>' + bar + '</button>';
    }).join('') + '</div>';
  }
  return h + '<div style="height:calc(22 * var(--u))"></div></div>';
}

/* ---------- Suche ---------- */
function norm(s) {
  return s.toLowerCase().replace(/ä/g,'a').replace(/ö/g,'o').replace(/ü/g,'u').replace(/ß/g,'ss')
    .replace(/[èé]/g,'e').replace(/[àá]/g,'a').replace(/[ìí]/g,'i').replace(/[òó]/g,'o').replace(/[ùú]/g,'u')
    .replace(/[^a-z0-9]/g, '');
}
var NAMES = DE.map(function (_, i) { return [norm(DE[i]), norm(EN[i]), norm(IT[i])]; });
function findBook(q) {
  var n = norm(q), i, j;
  if (!n) return -1;
  for (i = 0; i < 66; i++) for (j = 0; j < 3; j++) if (NAMES[i][j] === n) return i;
  for (i = 0; i < 66; i++) if (NAMES[i][lang() === 'de' ? 0 : lang() === 'it' ? 2 : 1].indexOf(n) === 0) return i;
  for (i = 0; i < 66; i++) for (j = 0; j < 3; j++) if (NAMES[i][j].indexOf(n) === 0) return i;
  return -1;
}
function doSearch(str) {
  var m = String(str).match(/^\s*((?:[1-3]\s*\.?\s*)?[A-Za-zÀ-ÿ]+(?:\s+[A-Za-zÀ-ÿ]+)*)\s*(\d+)?(?:\s*[:,.]\s*(\d+))?\s*$/);
  if (!m) { toast('Nichts gefunden'); return; }
  var b = findBook(m[1]);
  if (b < 0) { toast('Buch nicht gefunden'); return; }
  var c = Math.min(Math.max(parseInt(m[2] || '1', 10), 1), nch(b));
  var v = m[3] ? parseInt(m[3], 10) : 0;
  searchVal = '';
  openReader(b, c, v);
}

/* Vorschläge beim Tippen: Bücher, Kapitel, Verse */
function matchBooks(prefix) {
  var n = norm(prefix), cur = lang() === 'de' ? 0 : lang() === 'it' ? 2 : 1, out = [], i, j;
  if (!n) return out;
  for (i = 0; i < 66; i++) if (NAMES[i][cur].indexOf(n) === 0) out.push(i);
  for (i = 0; i < 66; i++) if (out.indexOf(i) < 0) for (j = 0; j < 3; j++) if (NAMES[i][j].indexOf(n) === 0) { out.push(i); break; }
  return out;
}
function suggRows(q) {
  q = String(q || '').trim();
  var rows = [], b, c, i, books;
  if (!q) return rows;
  if (/^[1-3]\s*\.?$/.test(q)) {
    books = matchBooks(q.replace(/\D/g, '')).slice(0, 5);
    books.forEach(function (bi) { rows.push({t:bname(bi), s:nch(bi) + ' Kap.', b:bi, c:1, v:0}); });
    return rows;
  }
  var m = q.match(/^((?:[1-3]\s*\.?\s*)?[A-Za-zÀ-ÿ]+(?:\s+[A-Za-zÀ-ÿ]+)*)\s*(\d+)?(?:\s*[:,.]\s*(\d*))?$/);
  if (!m) return rows;
  books = matchBooks(m[1]).slice(0, 5);
  if (m[2] === undefined) {
    books.forEach(function (bi) { rows.push({t:bname(bi), s:nch(bi) + ' Kap.', b:bi, c:1, v:0}); });
    return rows;
  }
  b = books[0]; if (b === undefined) return rows;
  var typed = m[2], max = nch(b);
  if (m[3] !== undefined) {
    c = parseInt(typed, 10); if (c < 1 || c > max) return rows;
    var vs = chapter(S.bible, b, c), vt = m[3];
    vs.filter(function (x) { return String(x.n).indexOf(vt) === 0; }).slice(0, 5).forEach(function (x) {
      rows.push({t:fmtRef(b, c, x.n), s:x.t.slice(0, 28) + '…', b:b, c:c, v:x.n});
    });
    if (!rows.length) rows.push({t:bname(b) + ' ' + c, s:'Kapitel', b:b, c:c, v:0});
    return rows;
  }
  for (i = 1; i <= max && rows.length < 5; i++) {
    if (String(i).indexOf(typed) === 0) rows.push({t:bname(b) + ' ' + i, s:'Kapitel', b:b, c:i, v:0});
  }
  return rows;
}
function syncQBtn() {
  var el = $('#qbtn'); if (!el) return;
  var has = !!searchVal;
  el.setAttribute('data-a', 'clearQ');
  el.innerHTML = has ? ic('x', 'mic') : '';
}
function applySugg() {
  var box = $('#sugg'), below = $('#below');
  if (!box) return;
  var qi = $('#q');
  var rows = (qi && !qi.readOnly) ? suggRows(searchVal) : [];
  box.innerHTML = rows.map(function (r) {
    return '<button class="row" data-a="sugg" data-b="' + r.b + '" data-c="' + r.c + '" data-v="' + r.v + '"><b>' + esc(r.t) +
      '</b><small>' + esc(r.s) + '</small>' + ic('book') + '</button>';
  }).join('');
  box.style.display = rows.length ? '' : 'none';
  if (below) below.style.display = rows.length ? 'none' : '';
}

/* ---------- Leser ---------- */
var R = {b:42, c:3, idx:0, menu:null, bsel:null, sel:null}, RV = [];

function recordRead(b, c) {
  S.last = {b:b, c:c};
  S.history = S.history.filter(function (x) { return !(x.b === b && x.c === c); });
  S.history.unshift({b:b, c:c, t:Date.now(), bid:S.bible});
  S.history = S.history.slice(0, 30);
  save();
}
function trackPos(i) {
  var it = R.scope;
  if (!it || it.b !== R.b || (it.t === 'c' && it.c !== R.c)) return;
  it.last = {c:R.c, i:Math.max(0, i)};
  save();
}
function openPlan(it, title) {
  var c = it.t === 'c' ? it.c : (it.last ? it.last.c : 1), i = it.last && it.last.c === c ? it.last.i : 0;
  var vs = chapter(S.bible, it.b, c);
  if (!vs.length) { c = 1; i = 0; vs = chapter(S.bible, it.b, 1); }
  openReader(it.b, c, vs[i] ? vs[i].n : 0, null, true, it);
  R.stitle = title || '';
  renderReader(true);
}
function openReader(b, c, v, bid, nosel, scope) {
  blurSearch();
  if (bid && bid !== S.bible) S.bible = bid;
  R = {b:b, c:c, idx:0, menu:null, bsel:null, sel:[], scope:scope || null};
  loadCfg(!!scope);
  var vs = chapter(S.bible, b, c);
  if (v) for (var i = 0; i < vs.length; i++) if (vs[i].n === v) { R.idx = i; R.sel = nosel ? [] : [i]; }
  recordRead(b, c);
  trackPos(R.idx);
  showOv('reader');
  renderReader(true);
}
function applyReadStyle() {
  var f = FONTS.filter(function (x) { return x.id === S.font; })[0] || FONTS[0];
  var px = SIZES[S.size] || 24;
  var st = document.documentElement.style;
  st.setProperty('--read', f.css);
  st.setProperty('--rs', 'calc(' + px + ' * var(--u))');
  st.setProperty('--rl', 'calc(' + (px * 1.354) + ' * var(--u))');
}
function targets() {
  if (!RV.length) return [];
  var idxs = S.focused ? [R.idx] : (R.sel || []);
  return idxs.filter(function (i) { return RV[i]; }).map(function (i) { return {b:R.b, c:R.c, v:RV[i].n}; });
}
function target() { return targets()[0] || null; }
function isMarked(t) {
  return S.marks.some(function (m) { return m.b === t.b && m.c === t.c && m.v === t.v && m.bid === S.bible; });
}
function actionsInner() {
  var ts = targets(), mk = ts.length > 0 && ts.every(isMarked);
  return '<button data-a="rShare">' + ic('share') + '<span class="cap">Teilen</span></button>' +
    '<button data-a="rMark">' + ic('heart', '', mk) + '<span class="cap">' + (mk ? 'Gemerkt' : 'Merken') + '</span></button>' +
    '<button data-a="rAdd">' + ic('folder') + '<span class="cap">Zur Sammlung</span></button>';
}
function focusVerse() {
  var v = RV[R.idx];
  if (!v) return '';
  var note = S.notes[nkey(R.b, R.c, v.n)];
  var hn = R.scope && !S.showVn;
  return '<div class="verse' + (hn ? ' nvn' : '') + (isMarked({b:R.b, c:R.c, v:v.n}) ? ' mk' : '') + '">' + (hn ? '' : '<span class="vn">' + v.n + '</span>') + '<span>' + esc(v.t) + '</span>' +
    (note ? '<div class="vnote">' + esc(note) + '</div>' : '') + '</div>';
}
function flowHtml(vs, b, c) {
  vs = vs || RV; b = b == null ? R.b : b; c = c || R.c;
  var h = S.showCh ? '<div class="chh">' + esc(bname(b) + ' ' + c) + '</div>' : '';
  return h + '<p class="flow">' + vs.map(function (v) {
    return '<span class="fv">' + (S.showVn ? '<sup>' + v.n + '</sup>' : '') + esc(v.t) + '</span>';
  }).join(' ') + '</p>';
}
function chNextBtn() {
  var b = R.b, c = R.c + 1;
  if (c > nch(b)) { b++; c = 1; }
  if (b > 65 || !canGo(b, c)) return '';
  return '<button class="chnext" data-a="chNext">Nächstes Kapitel ' + ic('right') + '</button>';
}
function chapStep(d) {
  var b = R.b, c = R.c + d;
  if (c < 1) { b--; if (b < 0) return; c = nch(b); }
  else if (c > nch(b)) { b++; c = 1; if (b > 65) return; }
  if (!canGo(b, c)) { toast('Ende der Auswahl'); return; }
  gotoChapter(b, c, d < 0);
}
var PG = {step:1, total:1, vx:[]};
function pagedBody() {
  if (R.scope) return flowHtml();
  return RV.map(function (v) {
    return '<div class="vp' + (isMarked({b:R.b, c:R.c, v:v.n}) ? ' mk' : '') + '"><span class="vn">' + v.n + '</span><span>' + esc(v.t) + '</span></div>';
  }).join('');
}
function bookCounts(W, H, gap) {
  var key = [R.b, S.bible, W, H, S.size, S.font, S.showVn].join('|');
  if (PG.bk && PG.bk.key === key) return PG.bk.counts;
  var m = document.createElement('div'), pc = document.createElement('div'), counts = [], k;
  m.className = 'pager'; m.style.visibility = 'hidden'; m.style.pointerEvents = 'none';
  pc.className = 'pcols'; m.appendChild(pc); $('#reader').appendChild(m);
  pc.style.height = H + 'px'; pc.style.width = W + 'px'; pc.style.columnWidth = W + 'px'; pc.style.columnGap = gap + 'px';
  for (k = 1; k <= nch(R.b); k++) {
    pc.innerHTML = flowHtml(chapter(S.bible, R.b, k), R.b, k);
    counts.push(Math.max(1, Math.round((pc.scrollWidth + gap) / (W + gap))));
  }
  m.parentNode.removeChild(m);
  PG.bk = {key:key, counts:counts};
  return counts;
}
function pageOfX(x) { return Math.floor((x + 2) / PG.step); }
function idxOfPage(p) {
  var k = 0;
  for (var i = 0; i < PG.vx.length; i++) if (pageOfX(PG.vx[i]) <= p) k = i;
  return k;
}
function renderPaged(bar) {
  var el = $('#reader');
  bar = bar.replace('<div class="bar', '<div id="pgbar"' + (R.pmenu || R.menu ? '' : ' hidden') + ' class="bar pgbar');
  var h = bar + '<div class="pager" id="pager"><div class="pcols" id="pcols">' + pagedBody() + '</div></div><div class="pgnum" id="pgnum"></div>' +
    '<div class="pgfoot" id="pgfoot"' + (R.pmenu ? '' : ' hidden') + '><button data-a="pgPrev">' + ic('left') + '</button><span id="pgl"></span><button data-a="pgNext">' + ic('right') + '</button></div>';
  if (R.menu === 'font') h += '<div class="pbg" data-a="rMenuClose" style="position:absolute;left:0;right:0;top:calc(71 * var(--u));bottom:0;z-index:7"></div>' + fontPop();
  el.innerHTML = h;
  var pager = $('#pager'), pc = $('#pcols'), W = pager.clientWidth, H = pager.clientHeight, gap = 40;
  pc.style.height = H + 'px'; pc.style.width = W + 'px'; pc.style.columnWidth = W + 'px'; pc.style.columnGap = gap + 'px';
  PG.step = W + gap;
  PG.total = Math.max(1, Math.round((pc.scrollWidth + gap) / PG.step));
  PG.all = 0; PG.off = 0;
  if (R.scope && R.scope.t === 'b' && !S.showCh) {
    var cn = bookCounts(W, H, gap), q;
    for (q = 0; q < cn.length; q++) { PG.all += cn[q]; if (q < R.c - 1) PG.off += cn[q]; }
    if (cn[R.c - 1]) PG.total = cn[R.c - 1];
  }
  var base = pc.getBoundingClientRect().left;
  PG.vx = [].map.call(pc.querySelectorAll('.fv,.vp'), function (e) { return e.getClientRects()[0].left - base; });
  var key = [R.b, R.c, W, H, S.size, S.font, S.showVn, S.showCh, S.bible].join('|');
  var p;
  if (R.pgLast) p = PG.total - 1;
  else if (R.pkey === key && R.page != null) p = R.page;
  else p = PG.vx.length ? pageOfX(PG.vx[Math.min(R.idx, PG.vx.length - 1)]) : 0;
  R.pgLast = false; R.pkey = key;
  showPage(Math.max(0, Math.min(p, PG.total - 1)), 0);
  fsSync();
}
function showPage(p, dir) {
  var pc = $('#pcols'), pager = $('#pager'); if (!pc) return;
  R.page = p;
  pc.style.transform = 'translateX(' + (-p * PG.step) + 'px)';
  var sp = (PG.all ? PG.off : 0) + p + 1, st = PG.all || PG.total;
  var t = $('#pgnum'); if (t) t.textContent = sp + ' / ' + st;
  t = $('#pgl'); if (t) t.textContent = 'Seite ' + sp + ' von ' + st;
  if (dir) {
    R.idx = idxOfPage(p); trackPos(R.idx);
    pager.classList.remove('wn', 'wp'); void pager.offsetWidth;
    pager.classList.add(dir > 0 ? 'wn' : 'wp');
  }
}
function pageMove(d) {
  var np = R.page + d;
  if (np >= 0 && np < PG.total) { showPage(np, d); return; }
  var b = R.b, c = R.c + d;
  if (c < 1) { b--; if (b < 0) return; c = nch(b); }
  else if (c > nch(b)) { b++; c = 1; if (b > 65) return; }
  if (!canGo(b, c)) { toast('Ende der Auswahl'); return; }
  gotoChapter(b, c, d < 0);
}
function sliderPos(n) { return n > 1 ? (R.idx / (n - 1)) * 100 : 0; }
function renderReader(scrollSel) {
  var el = $('#reader'), n;
  var keep = $('#rbody') ? $('#rbody').scrollTop : 0;
  RV = chapter(S.bible, R.b, R.c); n = RV.length;
  if (R.idx >= n) R.idx = Math.max(0, n - 1);
  applyReadStyle();
  var pct = n ? Math.round((S.focused ? R.idx + 1 : 1) / n * 100) : 0;
  var h = '<div class="bar' + (R.menu === 'books' ? ' compact' : '') + '"><button class="b-fertig" data-a="rClose">Fertig</button>' +
    '<button class="grow"' + (R.scope ? ' disabled' : ' data-a="rBooks"') + '><span>' + esc(R.scope ? (R.stitle || 'Sammlung') : bname(R.b) + ' ' + R.c) + '</span>' + (R.scope ? '' : ic('down')) + '</button>' +
    '<button class="aA" data-a="rFont"><small>a</small>A</button></div>';
  if (R.menu === 'books') {
    el.innerHTML = h + bookPanel();
    return;
  }
  if (S.mode === 'page' && n) { renderPaged(h); return; }
  h += '<div class="prog"><i id="prog" style="width:' + pct + '%"></i></div>';
  if (!n) {
    h += '<div class="rbody" id="rbody" style="font-family:var(--sans);font-size:calc(15 * var(--u));line-height:1.5"><p class="muted">Dieses Kapitel ist in „' +
      esc(slot(S.bible).name) + '“ nicht vorhanden.</p></div>';
  } else if (S.focused) {
    h += '<div class="rbody" id="rbody">' + focusVerse() + '</div><div class="rfoot"><div class="pos"><span>Position</span><b id="pos">' +
      (R.idx + 1) + ' von ' + n + '</b></div><div class="slider"><div class="trk"></div><div class="thumb" id="thumb" style="left:' + sliderPos(n) +
      '%"></div><input type="range" id="slider" min="1" max="' + n + '" value="' + (R.idx + 1) +
      '"></div><div class="acts" id="acts">' + actionsInner() + '</div></div>';
  } else if (R.scope) {
    h += '<div class="rbody" id="rbody">' + flowHtml() + chNextBtn() + '</div>';
  } else {
    h += '<div class="rbody" id="rbody">' + RV.map(function (v, i) {
      var note = S.notes[nkey(R.b, R.c, v.n)];
      return '<div class="vp' + (R.sel.indexOf(i) >= 0 ? ' sel' : '') + (isMarked({b:R.b, c:R.c, v:v.n}) ? ' mk' : '') + '" data-a="vsel" data-i="' + i + '"><span class="vn">' + v.n +
        '</span><span>' + esc(v.t) + '</span>' + (note ? '<div class="vnote">' + esc(note) + '</div>' : '') + '</div>';
    }).join('') + chNextBtn() + '</div>';
    if (R.sel.length) h += '<div class="rfoot"><div class="selinfo"><span>' + R.sel.length + (R.sel.length === 1 ? ' Vers ausgewählt' : ' Verse ausgewählt') +
      '</span><button data-a="selClear">Aufheben</button></div><div class="acts single" id="acts" style="margin-top:calc(8 * var(--u))">' + actionsInner() + '</div></div>';
  }
  if (R.menu === 'font') h += '<div class="pbg" data-a="rMenuClose" style="position:absolute;left:0;right:0;top:calc(71 * var(--u));bottom:0;z-index:7"></div>' + fontPop();
  el.innerHTML = h;
  var rb = $('#rbody');
  if (rb) {
    if (scrollSel) { var s = rb.querySelector('.vp.sel') || (R.idx ? rb.querySelector('.vp[data-i="' + R.idx + '"]') : null); if (s) s.scrollIntoView(); }
    else if (R.jump) rb.scrollTop = R.jump === 'end' ? rb.scrollHeight : 0;
    else rb.scrollTop = keep;
  }
  R.jump = null;
  fsSync();
}
function updateFocused() {
  var n = RV.length;
  $('#rbody').innerHTML = focusVerse();
  $('#rbody').scrollTop = 0;
  $('#pos').textContent = (R.idx + 1) + ' von ' + n;
  $('#prog').style.width = Math.round((R.idx + 1) / n * 100) + '%';
  var sl = $('#slider'); if (sl) sl.value = R.idx + 1;
  var th = $('#thumb'); if (th) th.style.left = sliderPos(n) + '%';
  $('#acts').innerHTML = actionsInner();
  trackPos(R.idx);
}
function fontPop() {
  return '<div class="pop fontpop"><span class="lbl">Übersetzung</span><div class="g3 tr">' + SLOTS.map(function (x) {
    return '<button data-a="rTrans" data-id="' + x.id + '" class="' + (S.bible === x.id ? 'on' : '') + '">' + x.short + '</button>';
  }).join('') + '</div><span class="lbl f2">Schriftart</span><div class="g3">' + FONTS.map(function (f) {
    return '<button data-a="setFont" data-id="' + f.id + '" class="' + (S.font === f.id ? 'on' : '') + '" style="font-family:' + f.css + '">' + f.name + '</button>';
  }).join('') + '</div><span class="lbl f2">Schriftgrösse</span><div class="g4">' + Object.keys(SIZES).map(function (k) {
    return '<button data-a="setSize" data-id="' + k + '" class="' + (S.size === k ? 'on' : '') + '">' + k + '</button>';
  }).join('') + '</div><span class="lbl f2">Lesemodus</span><div class="g3 md">' + [['focus', 'Focus'], ['scroll', 'Scroll'], ['page', 'Blättern']].map(function (m) {
      return '<button data-a="setMode" data-id="' + m[0] + '" class="' + (S.mode === m[0] ? 'on' : '') + '">' + m[1] + '</button>';
    }).join('') + '</div>' +
    '<div class="g3 ib">' + (R.scope ? '<button data-a="togVn" aria-label="Versnummern" class="' + (S.showVn ? 'on' : '') + '">' + ic('hash') + '</button>' +
      '<button data-a="togCh" aria-label="Kapitel" class="' + (S.showCh ? 'on' : '') + '">' + ic('bookm') + '</button>' : '') +
    '<button data-a="rDark" aria-label="Dunkelmodus" class="' + (S.dark ? 'on' : '') + '">' + ic('moon') + '</button></div></div>';
}
function bookPanel() {
  var h = '<div class="bp">';
  if (R.bsel == null) {
    var nt = R.tst === 1;
    h += '<div class="bphead"><span>Bibel</span><button data-a="rBooksClose">' + ic('x') + '</button></div>' +
      '<div class="tstbar"><button data-a="tst" data-t="0" class="' + (nt ? '' : 'on') + '">Altes Testament</button>' +
      '<button data-a="tst" data-t="1" class="' + (nt ? 'on' : '') + '">Neues Testament</button></div><div class="bpbody t"><div class="gbooks">';
    for (var i = nt ? 39 : 0; i < (nt ? 66 : 39); i++) h += '<button data-a="bookPick" data-b="' + i + '"><b>' + esc(bname(i)) + '</b><small>' + nch(i) + ' Kap.</small></button>';
    h += '</div></div>';
  } else {
    h += '<div class="bphead">' + (R.scope ? '' : '<button data-a="bookBack">' + ic('left') + '</button>') + '<span>' + esc(bname(R.bsel)) +
      '</span><button data-a="rBooksClose">' + ic('x') + '</button></div><div class="bpbody"><div class="gchap">';
    for (var c = 1; c <= nch(R.bsel); c++) h += '<button data-a="chapPick" data-c="' + c + '">' + c + '</button>';
    h += '</div></div>';
  }
  return h + '</div>';
}
function switchBible(id) {
  var n = RV[R.idx] ? RV[R.idx].n : 1, sns = (R.sel || []).filter(function (i) { return RV[i]; }).map(function (i) { return RV[i].n; });
  R.menu = null;
  if (id === S.bible) { renderReader(); return; }
  S.bible = id; save();
  if (R.c > nch(R.b)) R.c = nch(R.b);
  RV = chapter(S.bible, R.b, R.c);
  var find = function (x) { for (var i = 0; i < RV.length; i++) if (RV[i].n === x) return i; return -1; };
  var k = find(n); R.idx = k >= 0 ? k : Math.max(0, Math.min(R.idx, RV.length - 1));
  R.sel = sns.map(find).filter(function (i) { return i >= 0; });
  recordRead(R.b, R.c);
  renderReader();
}
function gotoChapter(b, c, last) {
  R.b = b; R.c = c; R.sel = []; R.menu = null;
  RV = chapter(S.bible, b, c);
  R.idx = last ? Math.max(0, RV.length - 1) : 0;
  R.jump = last ? 'end' : 'start'; R.pgLast = !!last;
  recordRead(b, c);
  trackPos(R.idx);
  renderReader();
}
function canGo(b, c) {
  var sc = R.scope;
  return !sc || (b === sc.b && (sc.t !== 'c' || c === sc.c));
}
function nextVerse() {
  if (R.idx < RV.length - 1) { R.idx++; updateFocused(); return; }
  if (R.c < nch(R.b) && canGo(R.b, R.c + 1)) gotoChapter(R.b, R.c + 1, false);
  else if (R.b < 65 && canGo(R.b + 1, 1)) gotoChapter(R.b + 1, 1, false);
  else if (R.scope) toast('Ende der Auswahl');
}
function prevVerse() {
  if (R.idx > 0) { R.idx--; updateFocused(); return; }
  if (R.c > 1 && canGo(R.b, R.c - 1)) gotoChapter(R.b, R.c - 1, true);
  else if (R.b > 0 && R.c === 1 && canGo(R.b - 1, nch(R.b - 1))) gotoChapter(R.b - 1, nch(R.b - 1), true);
}

/* ---------- Kommentar / Merken / Hinzufügen ---------- */
function commentDialog() {
  var t = target(); if (!t) return;
  var cur = S.notes[nkey(t.b, t.c, t.v)] || '';
  modal('<div class="mbox"><h3>' + esc(fmtRef(t.b, t.c, t.v)) + '</h3><textarea class="field" id="cmt" placeholder="Kommentar …">' + esc(cur) +
    '</textarea><div class="btns"><button class="dark" data-a="cmtSave">Speichern</button>' +
    (cur ? '<button class="c" data-a="cmtDel">Löschen</button>' : '') + '<button class="c" data-a="closeModal">Abbrechen</button></div></div>');
}
function toggleMark() {
  var ts = targets(); if (!ts.length) return;
  var same = function (m, t) { return m.b === t.b && m.c === t.c && m.v === t.v && m.bid === S.bible; };
  if (ts.every(isMarked)) {
    S.marks = S.marks.filter(function (m) { return !ts.some(function (t) { return same(m, t); }); });
    toast(ts.length > 1 ? ts.length + ' Merkungen entfernt' : 'Merkung entfernt');
  } else {
    ts.forEach(function (t) { if (!isMarked(t)) S.marks.push({b:t.b, c:t.c, v:t.v, bid:S.bible}); });
    toast(ts.length > 1 ? ts.length + ' Verse gemerkt' : 'Gemerkt');
  }
  save();
  var a = $('#acts'); if (a) a.innerHTML = actionsInner();
  var rb = $('#rbody');
  if (S.focused && rb && RV[R.idx]) { var st = rb.scrollTop; rb.innerHTML = focusVerse(); rb.scrollTop = st; }
}
var addRef = null;
function addDialog(ref) {
  addRef = ref;
  var h = '<div class="mbox"><h3>Zur Sammlung hinzufügen</h3><div class="btns">';
  S.andachten.forEach(function (a) {
    h += '<button data-a="addPick" data-id="' + a.id + '">' + ic('book') + '<span class="tt">' + esc(a.title || 'Ohne Titel') + '</span></button>';
  });
  h += '<button data-a="addNew">' + ic('plus') + 'Neue Sammlung</button><button class="c" data-a="closeModal">Abbrechen</button></div></div>';
  modal(h);
}
function addVerseTo(a, ref) {
  var list = [].concat(ref || addRef || []); if (!list.length) return;
  var n = 0;
  a.plan = a.plan || [];
  list.forEach(function (r) {
    if (r.t === 'b' || r.t === 'c') {
      if (a.plan.some(function (x) { return x.t === r.t && x.b === r.b && (r.t === 'b' || x.c === r.c); })) return;
      a.plan.push({t:r.t, b:r.b, c:r.t === 'c' ? r.c : 0, last:null});
      n++; return;
    }
    var bid = r.bid || S.bible;
    if (a.verses.some(function (x) { return x.b === r.b && x.c === r.c && x.v === r.v && x.bid === bid; })) return;
    a.verses.push({b:r.b, c:r.c, v:r.v, bid:bid});
    n++;
  });
  if (!n) { toast('Schon in dieser Sammlung'); return; }
  save();
  toast(n > 1 ? n + ' Einträge zur Sammlung hinzugefügt' : 'Zur Sammlung hinzugefügt');
}
function newAndacht() {
  var a = {id:'a' + Date.now(), title:'', verses:[], plan:[]};
  S.andachten.unshift(a); save();
  return a;
}
function findAndacht(id) {
  for (var i = 0; i < S.andachten.length; i++) if (S.andachten[i].id === id) return S.andachten[i];
  return null;
}

/* ---------- Teilen: Vers als Bild ---------- */
var SH = null;
function drawVerse(o, f) {
  var W = 1080, M = 30, P = 76, L = M + P, CW = W - 2 * L;
  var tfont = '400 58px ' + f.css, rfont = "700 56px 'Newsreader',Georgia,serif", ffont = "600 27px 'Plus Jakarta Sans',Arial,sans-serif";
  var qs = lang(o.bid) === 'de' ? ['\u201E', '\u201C'] : ['\u201C', '\u201D'];
  var sc = document.createElement('canvas').getContext('2d');
  sc.font = tfont;
  var words = (qs[0] + o.text + qs[1]).split(/\s+/), lines = [], cur = '';
  words.forEach(function (w) {
    var t = cur ? cur + ' ' + w : w;
    if (sc.measureText(t).width > CW && cur) { lines.push(cur); cur = w; } else cur = t;
  });
  if (cur) lines.push(cur);
  var LH = 86, y0 = M + P, refBase = y0 + 50, textBase = refBase + 44 + 58;
  var endText = textBase + (lines.length - 1) * LH;
  var H = Math.max(endText + 64 + 70 + P + M, 720);
  var cv = document.createElement('canvas'); cv.width = W; cv.height = H;
  var cx = cv.getContext('2d');
  cx.fillStyle = '#FBF8F4'; cx.fillRect(0, 0, W, H);
  var r = 30, x1 = M, y1 = M, x2 = W - M, y2 = H - M;
  cx.lineWidth = 6; cx.strokeStyle = '#1B1918'; cx.beginPath();
  cx.moveTo(x1 + r, y1); cx.lineTo(x2 - r, y1); cx.arcTo(x2, y1, x2, y1 + r, r); cx.lineTo(x2, y2 - r); cx.arcTo(x2, y2, x2 - r, y2, r);
  cx.lineTo(x1 + r, y2); cx.arcTo(x1, y2, x1, y2 - r, r); cx.lineTo(x1, y1 + r); cx.arcTo(x1, y1, x1 + r, y1, r); cx.closePath(); cx.stroke();
  cx.fillStyle = '#1B1918'; cx.textBaseline = 'alphabetic';
  cx.font = rfont; cx.fillText(o.label || fmtRef(o.t.b, o.t.c, o.t.v, o.bid), L, refBase);
  cx.font = tfont;
  lines.forEach(function (ln, i) { cx.fillText(ln, L, textBase + i * LH); });
  var fb = y2 - P - 8, dy = fb - 27 - 30;
  cx.fillStyle = '#1B1918'; cx.fillRect(L, dy, CW, 3);
  cx.fillStyle = '#5A554E'; cx.font = ffont;
  try { cx.letterSpacing = '3px'; } catch (e) {}
  cx.textAlign = 'left'; cx.fillText('MINIMALIST BIBLE', L, fb);
  cx.textAlign = 'right'; cx.fillText(slot(o.bid).name.toUpperCase(), L + CW, fb);
  return cv;
}
function makeVerseImage(o, cb) {
  var f = FONTS.filter(function (x) { return x.id === S.font; })[0] || FONTS[0], done = false;
  function go() { if (done) return; done = true; cb(drawVerse(o, f)); }
  try {
    Promise.all([document.fonts.load("700 56px 'Newsreader'"), document.fonts.load('400 58px ' + f.css), document.fonts.load("600 27px 'Plus Jakarta Sans'")]).then(go, go);
    setTimeout(go, 1500);
  } catch (e) { go(); }
}
function refLabel(ts, bid) {
  var runs = [], cur = null;
  ts.forEach(function (t) { if (cur && t.v === cur.e + 1) cur.e = t.v; else { cur = {s:t.v, e:t.v}; runs.push(cur); } });
  var out = fmtRef(ts[0].b, ts[0].c, runs[0].s, bid) + (runs[0].e > runs[0].s ? '\u2013' + runs[0].e : '');
  for (var i = 1; i < runs.length; i++) out += ', ' + runs[i].s + (runs[i].e > runs[i].s ? '\u2013' + runs[i].e : '');
  return out;
}
function openShare() {
  var ts = targets(); if (!ts.length) return;
  var tx = ts.map(function (t) { return verseText(S.bible, t.b, t.c, t.v); }).filter(Boolean).join(' ');
  if (!tx) { toast('Kein Text vorhanden'); return; }
  SH = {t:ts[0], label:refLabel(ts, S.bible), text:tx, bid:S.bible, url:null, b64:null, blob:null, note:''};
  showOv('share'); renderShare();
  makeVerseImage(SH, function (cv) {
    SH.url = cv.toDataURL('image/png'); SH.b64 = SH.url.split(',')[1];
    cv.toBlob(function (bl) { SH.blob = bl; }, 'image/png');
    renderShare();
  });
}
function renderShare() {
  var el = $('#share');
  el.innerHTML = '<div class="bar"><button class="b-close" data-a="shClose">' + ic('x', 'l') + 'Schließen</button><span class="lbl state">Vorschau</span><span style="width:90px"></span></div>' +
    '<div class="shbody"><div class="paper">' + (SH && SH.url ? '<img alt="" src="' + SH.url + '">' : '<div class="wait">Bild wird erstellt …</div>') + '</div>' +
    '<p class="shnote" id="shnote">' + esc(SH && SH.note || '') + '</p></div>' +
    '<div class="shfoot"><button class="pri" data-a="shCopy">' + ic('copy') + '<span class="cap">Kopieren</span></button>' +
    '<button data-a="shSave">' + ic('down2') + '<span class="cap">Galerie</span></button>' +
    '<button data-a="shSend">' + ic('share') + '<span class="cap">Teilen</span></button></div>';
}
function shNote(t) { if (SH) SH.note = t; var n = $('#shnote'); if (n) n.textContent = t; }
function copyShare(auto) {
  if (!SH || !SH.b64) return;
  var ok = false;
  try { if (window.Android && Android.copyImage) ok = !!Android.copyImage(SH.b64); } catch (e) { ok = false; }
  if (ok) { shNote('Bild in die Zwischenablage kopiert. Du kannst es jetzt in jeder App einfügen.'); toast('Bild kopiert'); return; }
  try {
    if (navigator.clipboard && window.ClipboardItem && SH.blob) {
      navigator.clipboard.write([new ClipboardItem({'image/png': SH.blob})]).then(function () {
        shNote('Bild in die Zwischenablage kopiert. Du kannst es jetzt in jeder App einfügen.'); toast('Bild kopiert');
      }, function () { shNote('Kopieren nicht möglich – nutze „Teilen …“.'); });
      return;
    }
  } catch (e) {}
  shNote('Kopieren nicht möglich – nutze „Teilen …“.');
}
function saveShare() {
  if (!SH || !SH.b64) return;
  var ok = false;
  try { if (window.Android && Android.saveToGallery) ok = !!Android.saveToGallery(SH.b64); } catch (e) { ok = false; }
  if (ok) { shNote('Bild in der Galerie gespeichert (Ordner „Minimalist Bible“ unter Bilder).'); toast('In Galerie gespeichert'); return; }
  try {
    if (!window.Android && SH.url) {
      var a = document.createElement('a'); a.href = SH.url; a.download = 'vers.png'; document.body.appendChild(a); a.click(); a.remove();
      shNote('Bild heruntergeladen.'); return;
    }
  } catch (e) {}
  shNote('Speichern nicht möglich.'); toast('Speichern nicht möglich');
}
function sendShare() {
  if (!SH || !SH.b64) return;
  var ok = false;
  try { if (window.Android && Android.shareImage) ok = !!Android.shareImage(SH.b64); } catch (e) { ok = false; }
  if (ok) return;
  try {
    if (navigator.share && SH.blob) { navigator.share({files:[new File([SH.blob], 'vers.png', {type:'image/png'})]}); return; }
  } catch (e) {}
  toast('Teilen nicht möglich');
}

/* ---------- Andacht ---------- */
var A = {id:null, edit:false, card:null};
function openAndacht(id, edit) {
  A = {id:id, edit:!!edit, card:null};
  showOv('andacht');
  renderAndacht();
}
function renderAndacht() {
  var a = findAndacht(A.id), el = $('#andacht');
  if (!a) { hideOv('andacht'); return; }
  applyReadStyle();
  var h, pl = a.plan || [];
  var close = '<button class="b-close" data-a="aClose">' + ic('x', 'l') + 'Schließen</button>';
  if (!A.edit) {
    h = '<div class="bar">' + close + '<span class="lbl state">Privat</span>' +
      '<button class="b-main dark" data-a="aEdit">Bearbeiten</button></div><div class="scroll view"><span class="lbl a">Sammlung</span><h2>' +
      esc(a.title || 'Ohne Titel') + '</h2>';
    pl.forEach(function (it, i) {
      var pc = planPct([it]);
      h += '<button class="pcard" data-a="planOpen" data-i="' + i + '"><b>' + esc(planName(it)) + '</b><small>' +
        (it.last ? 'Weiterlesen bei Kap. ' + it.last.c + ', Vers ' + (it.last.i + 1) : 'Noch nicht begonnen') + ' · ' + pc + ' %</small>' +
        '<span class="pbar"><i style="width:' + pc + '%"></i></span></button>';
    });
    if (a.verses.length) {
      h += '<button class="btn-v" data-a="aRead">' + ic('play') + '<span class="cap">Durchblättern</span></button><div class="grid2 cvg">' +
        a.verses.map(function (v, i) { return '<button class="vt" data-a="cvOpen" data-i="' + i + '">' + esc(fmtRef(v.b, v.c, v.v, v.bid)) + '</button>'; }).join('') + '</div>';
    }
    if (!pl.length && !a.verses.length) h += '<p class="muted" style="margin-top:18px">Noch leer. Füge im Leser Verse hinzu oder halte in der Bücherauswahl ein Buch oder Kapitel gedrückt.</p>';
    h += '<div style="height:calc(30 * var(--u))"></div></div>';
    if (A.card != null && a.verses[A.card]) {
      var cv = a.verses[A.card], cg = verseText(cv.bid, cv.b, cv.c, cv.v) ? {t:verseText(cv.bid, cv.b, cv.c, cv.v), bid:cv.bid} : anyText(cv.b, cv.c, cv.v, cv.bid);
      h += '<div class="card pin"><div class="ch"><span class="lbl">' + esc(a.title || 'Sammlung') + '</span><button data-a="cvClose" aria-label="Schließen">' + ic('x') + '</button></div>' +
        '<div class="cb"><div class="cref">' + esc(fmtRef(cv.b, cv.c, cv.v, cv.bid)) + '</div><div class="ctext">' +
        (cg ? '„' + esc(cg.t) + '“' : '<span class="muted">Text nicht eingebaut.</span>') + '</div></div>' +
        '<div class="cf"><button class="primary" data-a="cvStep" data-i="' + A.card + '">' + ic('play') + 'Durchblättern ab hier</button></div></div>';
    }
  } else {
    var vlist = '';
    pl.forEach(function (it, i) {
      vlist += '<div class="vitem"><div class="vh"><span>' + esc(planName(it)) + '</span><button data-a="aRemP" data-i="' + i + '" aria-label="Entfernen">' + ic('x') + '</button></div></div>';
    });
    a.verses.forEach(function (v, i) {
      vlist += '<div class="vitem"><div class="vh"><span>' + esc(fmtRef(v.b, v.c, v.v, v.bid)) + '</span><button data-a="aRemV" data-i="' + i +
        '" aria-label="Entfernen">' + ic('x') + '</button></div></div>';
    });
    h = '<div class="bar">' + close + '<span class="lbl state">Privat</span>' +
      '<button class="b-main dark" data-a="aDone">Fertig</button></div><div class="scroll edit"><span class="lbl a">Sammlung</span>' +
      '<input class="field t" id="aTitle" placeholder="Überschrift" value="' + esc(a.title) + '">' +
      '<button class="btn-del" data-a="aDel">' + ic('trash', 'l') + 'Löschen</button>' +
      (vlist ? '<div class="vl"><span class="lbl">Inhalt</span>' + vlist + '</div>' : '') + '</div>';
  }
  el.innerHTML = h;
}

/* ---------- Verse lesen (Stepper) ---------- */
var ST = {id:null, i:0};
function openStepper(id, i0) {
  var a = findAndacht(id);
  if (!a || !a.verses.length) { toast('Keine Verse in dieser Sammlung'); return; }
  ST = {id:id, i:Math.max(0, Math.min(i0 || 0, a.verses.length - 1))};
  showOv('stepper');
  renderStepper();
}
function renderStepper() {
  var a = findAndacht(ST.id), el = $('#stepper');
  if (!a || !a.verses.length) { hideOv('stepper'); return; }
  var n = a.verses.length, v = a.verses[ST.i];
  var got = verseText(v.bid, v.b, v.c, v.v) ? {t:verseText(v.bid, v.b, v.c, v.v), bid:v.bid} : anyText(v.b, v.c, v.v, v.bid);
  el.innerHTML = '<div class="bar"><button class="b-close" data-a="stClose">' + ic('x', 'l') + 'Fertig</button><span class="lbl mid">' + esc(a.title || 'Sammlung') + '</span></div>' +
    '<div class="prog"><i style="width:' + Math.round((ST.i + 1) / n * 100) + '%"></i></div>' +
    '<div class="scroll st" style="padding:0"><span class="lbl r">' + esc(fmtRef(v.b, v.c, v.v, v.bid).replace(/ (\d+)[,:](\d+)$/, ' $1:$2')) + '</span><div class="stext">' +
    (got ? '„' + esc(got.t) + '“' : '<span class="muted" style="font-family:var(--sans);font-size:calc(14 * var(--u))">Text nicht eingebaut.</span>') +
    '</div>' + '</div>' +
    '<div class="sfoot"><div class="nav2"><button data-a="stPrev"' + (ST.i === 0 ? ' disabled' : '') + '>' + ic('left') + '<span class="cap">Zurück</span></button>' +
    '<button data-a="stNext"' + (ST.i === n - 1 ? ' disabled' : '') + '>' + ic('right') + '<span class="cap">Weiter</span></button></div>' +
    '<div class="sinfo"><span class="lbl">' + (ST.i + 1) + ' von ' + n + '</span><span></span></div></div>';
}
function stStep(d) {
  var a = findAndacht(ST.id); if (!a) return;
  var i = ST.i + d;
  if (i < 0 || i >= a.verses.length) return;
  ST.i = i; renderStepper();
}

/* ---------- Profil / Import ---------- */
var pending = null;
function applyTheme() { document.documentElement.classList.toggle('dark', !!S.dark); }

var LEGAL = {name:'[NAME DES HERAUSGEBERS]', email:'[E-MAIL]', place:'[ORT, LAND]'};
var OFL = "SIL OPEN FONT LICENSE Version 1.1 - 26 February 2007\n\nPREAMBLE\nThe goals of the Open Font License (OFL) are to stimulate worldwide development of collaborative font projects, to support the font creation efforts of academic and linguistic communities, and to provide a free and open framework in which fonts may be shared and improved in partnership with others.\n\nThe OFL allows the licensed fonts to be used, studied, modified and redistributed freely as long as they are not sold by themselves. The fonts, including any derivative works, can be bundled, embedded, redistributed and/or sold with any software provided that any reserved names are not used by derivative works. The fonts and derivatives, however, cannot be released under any other type of license. The requirement for fonts to remain under this license does not apply to any document created using the fonts or their derivatives.\n\nDEFINITIONS\n\"Font Software\" refers to the set of files released by the Copyright Holder(s) under this license and clearly marked as such. This may include source files, build scripts and documentation.\n\n\"Reserved Font Name\" refers to any names specified as such after the copyright statement(s).\n\n\"Original Version\" refers to the collection of Font Software components as distributed by the Copyright Holder(s).\n\n\"Modified Version\" refers to any derivative made by adding to, deleting, or substituting -- in part or in whole -- any of the components of the Original Version, by changing formats or by porting the Font Software to a new environment.\n\n\"Author\" refers to any designer, engineer, programmer, technical writer or other person who contributed to the Font Software.\n\nPERMISSION & CONDITIONS\nPermission is hereby granted, free of charge, to any person obtaining a copy of the Font Software, to use, study, copy, merge, embed, modify, redistribute, and sell modified and unmodified copies of the Font Software, subject to the following conditions:\n\n1) Neither the Font Software nor any of its individual components, in Original or Modified Versions, may be sold by itself.\n\n2) Original or Modified Versions of the Font Software may be bundled, redistributed and/or sold with any software, provided that each copy contains the above copyright notice and this license. These can be included either as stand-alone text files, human-readable headers or in the appropriate machine-readable metadata fields within text or binary files as long as those fields can be easily viewed by the user.\n\n3) No Modified Version of the Font Software may use the Reserved Font Name(s) unless explicit written permission is granted by the corresponding Copyright Holder. This restriction only applies to the primary font name as presented to the users.\n\n4) The name(s) of the Copyright Holder(s) or the Author(s) of the Font Software shall not be used to promote, endorse or advertise any Modified Version, except to acknowledge the contribution(s) of the Copyright Holder(s) and the Author(s) or with their explicit written permission.\n\n5) The Font Software, modified or unmodified, in part or in whole, must be distributed entirely under this license, and must not be distributed under any other license. The requirement for fonts to remain under this license does not apply to any document created using the Font Software.\n\nTERMINATION\nThis license becomes null and void if any of the above conditions are not met.\n\nDISCLAIMER\nTHE FONT SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO ANY WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT OF COPYRIGHT, PATENT, TRADEMARK, OR OTHER RIGHT. IN NO EVENT SHALL THE COPYRIGHT HOLDER BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, INCLUDING ANY GENERAL, SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF THE USE OR INABILITY TO USE THE FONT SOFTWARE OR FROM OTHER DEALINGS IN THE FONT SOFTWARE.";
function infoBody(kind) {
  var P = function (t) { return '<p>' + esc(t) + '</p>'; }, H = function (t) { return '<h3>' + esc(t) + '</h3>'; };
  if (kind === 'about') {
    return H('Minimalist Bible') + P('Version 22. Offline-Bibel für E-Ink-Geräte. Die App benötigt keinen Internetzugang.') +
      H('Bibelübersetzungen') +
      P('Berean Standard Bible (BSB): gemeinfrei (Public Domain).') +
      P('Schlachter 1951: Der Text wird kostenlos und ohne Gewinnabsicht mitgeliefert. Die Rechte liegen bei den jeweiligen Rechteinhabern.') +
      P('Riveduta: Der Text wird kostenlos und ohne Gewinnabsicht mitgeliefert. Die Rechte liegen bei den jeweiligen Rechteinhabern.') +
      P('Eigene Bibeln kannst du über „Bibel importieren“ hinzufügen. Importiere nur Texte, für die du die Rechte hast.') +
      H('Schriften (SIL Open Font License 1.1)') +
      P('Newsreader: Copyright 2020 The Newsreader Project Authors (https://github.com/productiontype/Newsreader)') +
      P('Source Serif 4: Copyright 2014–2021 Adobe (http://www.adobe.com/), mit dem reservierten Schriftnamen „Source“.') +
      P('Plus Jakarta Sans: Copyright 2020 The Plus Jakarta Sans Project Authors (https://github.com/tokotype/PlusJakartaSans)') +
      P('Lora: Copyright 2011 The Lora Project Authors (https://github.com/cyrealtype/Lora-Cyrillic)') +
      P('Inter: Copyright 2016 The Inter Project Authors (https://github.com/rsms/inter)') +
      H('Lizenztext der Schriften') + '<pre>' + esc(OFL) + '</pre>' +
      H('Herausgeber') + P(LEGAL.name + ', ' + LEGAL.place + ' · ' + LEGAL.email);
  }
  if (kind === 'privacy') {
    return H('Datenschutzerklärung') +
      P('Verantwortlich: ' + LEGAL.name + ', ' + LEGAL.place + ', ' + LEGAL.email) +
      H('Daten bleiben auf dem Gerät') +
      P('Minimalist Bible hat keinen Internetzugang und sendet keine Daten an den Herausgeber oder Dritte. Es gibt keine Konten, keine Werbung und keine Analyse- oder Tracking-Dienste.') +
      H('Welche Daten gespeichert werden') +
      P('Name und Profilbild (freiwillig), Gemerktes, Sammlungen mit Überschriften, Leseverlauf und Lesepositionen, Einstellungen sowie von dir importierte Bibeln. Sammlungen und Gemerktes können Rückschlüsse auf religiöse Überzeugungen zulassen; sie werden ausschließlich lokal in der App gespeichert.') +
      H('Backup') +
      P('Die App ist von der Android-Datensicherung ausgenommen. Die Daten werden nicht in ein Cloud-Backup kopiert.') +
      H('Teilen') +
      P('Wenn du ein Vers-Bild teilst oder in die Galerie speicherst, geschieht das nur nach deiner Aktion und mit der App, die du auswählst. Dafür gilt deren Datenschutzerklärung.') +
      H('Löschen') +
      P('Du kannst alle Daten jederzeit löschen: mit dem Button unten oder durch Deinstallation der App.') +
      '<button class="wipe" data-a="wipeAsk">Alle Daten löschen</button>' +
      H('Deine Rechte') +
      P('Da der Herausgeber keine Daten von dir erhält, kann er keine Auskunft über sie geben. Bei Fragen schreibe an ' + LEGAL.email + '.');
  }
  return H('Nutzungsbedingungen') +
    P('Mit der Nutzung von Minimalist Bible stimmst du diesen Bedingungen zu.') +
    P('1. Lizenz: Du darfst die App für private, nicht-kommerzielle Zwecke auf deinen Geräten nutzen. Die App und ihre Gestaltung bleiben Eigentum des Herausgebers (' + LEGAL.name + '). Weitergabe, Verkauf und Veränderung der App sind ohne Erlaubnis nicht gestattet.') +
    P('2. Bibeltexte: Die mitgelieferten Übersetzungen unterliegen den unter „Über / Lizenzen“ genannten Bedingungen. Sie dürfen nur privat und nicht-kommerziell genutzt werden. Importierte Texte darfst du nur nutzen, wenn du die Rechte daran hast.') +
    P('3. Eigene Inhalte: Name, Notizen und Sammlungen bleiben auf deinem Gerät. Du bist für sie selbst verantwortlich.') +
    P('4. Haftung: Die App wird ohne Gewähr bereitgestellt. Der Herausgeber haftet nur bei Vorsatz und grober Fahrlässigkeit sowie nach den gesetzlichen Vorschriften für Personenschäden. Für Datenverlust, etwa durch Gerätewechsel oder Löschen der App, wird nicht gehaftet. Sichere wichtige Inhalte selbst.') +
    P('5. Änderungen: Der Herausgeber kann diese Bedingungen mit einem App-Update ändern.') +
    P('6. Kontakt: ' + LEGAL.name + ', ' + LEGAL.place + ', ' + LEGAL.email);
}
function openInfo(kind) {
  var t = {about:'Über / Lizenzen', privacy:'Datenschutz', terms:'Bedingungen'}[kind] || '';
  $('#info').innerHTML = '<div class="bar"><button class="b-close" data-a="infoClose">' + ic('x', 'l') + 'Schließen</button><span class="lbl state">' + esc(t) + '</span></div>' +
    '<div class="scroll view infotxt">' + infoBody(kind) + '<div style="height:calc(30 * var(--u))"></div></div>';
  showOv('info');
}
function profileDialog() {
  modal('<div class="profmenu"><div class="who"><b>' + esc(S.name) + '</b><span>Version 22</span><span>' + SLOTS.filter(function (x) { return isFull(x.id); }).length + ' von ' + SLOTS.length + ' Bibeln vollständig</span></div>' +
    '<button data-a="imgPick">' + ic('camera') + 'Profilbild ändern</button>' +
    '<button data-a="nameEdit">' + ic('pencil') + 'Name ändern</button>' +
    '<button data-a="toggleDark">' + ic('moon') + 'Dunkelmodus<span class="st">' + (S.dark ? 'AN' : 'AUS') + '</span></button>' +
    '<button data-a="importBible">' + ic('upload') + 'Bibel importieren</button>' +
    '<button data-a="info" data-id="about">' + ic('book') + 'Über / Lizenzen</button>' +
    '<button data-a="info" data-id="privacy">' + ic('folder') + 'Datenschutz</button>' +
    '<button data-a="info" data-id="terms">' + ic('pencil') + 'Nutzungsbedingungen</button></div>', true);
}
function slotPicker() {
  var h = '<div class="mbox"><h3>Welche Übersetzung ist das?</h3><p class="muted">Wähle den Platz, auf dem die Bibel gespeichert wird.</p><div class="btns">';
  SLOTS.forEach(function (s) {
    var has = false; try { has = !!(window.Android && Android.hasBible(s.id)); } catch (e) {}
    h += '<button data-a="slotPick" data-id="' + s.id + '"><span style="flex:1">' + esc(s.name) + '</span>' + (has ? '<small>ersetzen</small>' : '') + '</button>';
  });
  modal(h + '<button class="c" data-a="closeModal">Abbrechen</button></div></div>');
}
function errDialog(title, msg) {
  modal('<div class="mbox"><h3>' + esc(title) + '</h3><p>' + esc(msg) + '</p><div class="btns"><button class="c dark" data-a="closeModal">OK</button></div></div>');
}
function handleBibleFile(file) {
  var rd = new FileReader();
  rd.onload = function () {
    var txt = String(rd.result).replace(/^﻿/, '');
    try {
      var d = toDense(JSON.parse(txt));
      if (!d || d.length !== 66) throw new Error('66');
      pending = txt;
      slotPicker();
    } catch (e) {
      errDialog('Import nicht möglich', 'Die Datei ist keine passende Bibel-Datei. Erwartet wird eine JSON-Datei mit 66 Büchern (1. Mose bis Offenbarung).');
    }
  };
  rd.onerror = function () { errDialog('Import nicht möglich', 'Die Datei konnte nicht gelesen werden.'); };
  rd.readAsText(file);
}
function handleImage(file) {
  var url = URL.createObjectURL(file), img = new Image();
  img.onload = function () {
    var s = Math.min(img.width, img.height), cv = document.createElement('canvas');
    cv.width = cv.height = 112;
    var cx = cv.getContext('2d');
    cx.drawImage(img, (img.width - s) / 2, (img.height - s) / 2, s, s, 0, 0, 112, 112);
    S.img = cv.toDataURL('image/jpeg', 0.8); save();
    URL.revokeObjectURL(url); renderMain();
  };
  img.onerror = function () { toast('Bild konnte nicht gelesen werden'); };
  img.src = url;
}

/* ---------- Aktionen ---------- */
var menuCtx = null;
function tileMenu(el) {
  var i = parseInt(el.getAttribute('data-i'), 10), p = S.marks[i];
  if (!p) return;
  menuCtx = {i:i};
  var r = el.getBoundingClientRect(), u = window.innerWidth / 369;
  var left = Math.min(r.left, window.innerWidth - 246.5 * u - 4);
  var top = Math.max(4, Math.min(r.top - 4 * u, window.innerHeight - 236 * u - 8));
  modal('<div class="ctxmenu" style="left:' + left + 'px;top:' + top + 'px">' +
    '<button data-a="tileOpen">In der Bibel öffnen</button>' +
    '<button data-a="tilePin">' + (p.pin ? 'Lösen' : 'Oben anheften') + '</button>' +
    '<button data-a="tileColl">Zur Sammlung hinzufügen</button>' +
    '<button data-a="tileDel">Vers entfernen</button></div>', true);
}
function showPinCard(i) {
  var p = S.marks[i]; if (!p) return;
  card = {kind:'marks', b:p.b, c:p.c, v:p.v, bid:p.bid};
  renderMain();
}
function openFromList(i) {
  var p = S.marks[i]; if (!p) return;
  openReader(p.b, p.c, p.v, p.bid);
}

function act(a, d, el) {
  var i, x;
  switch (a) {
    case 'tab':
      if (d.t === 'start' && tab === 'start' && !stack.length) {
        card = null; startPanel = null; searchActive = true; renderMain();
        x = $('#q'); if (x) x.focus();
        break;
      }
      setTab(d.t); break;
    case 'profile': profileDialog(); break;
    case 'toggleDark': S.dark = !S.dark; save(); applyTheme(); profileDialog(); break;
    case 'closeModal': closeModal(); break;
    case 'trans': startPanel = startPanel === 'trans' ? null : 'trans'; renderMain(); break;
    case 'setBible': S.bible = d.id; save(); startPanel = null; renderMain(); break;
    case 'random': startPanel = null; card = randomRef(card); renderMain(); break;
    case 'votd': card = votdRef(); renderMain(); break;
    case 'randomMark':
      if (!S.marks.length) break;
      var rm1 = S.marks.length, rm2 = Math.floor(Math.random() * rm1);
      if (rm1 > 1 && rm2 === lastRandMark) rm2 = (rm2 + 1 + Math.floor(Math.random() * (rm1 - 1))) % rm1;
      lastRandMark = rm2; showPinCard(rm2); break;
    case 'closeCard': card = null; renderMain(); break;
    case 'openVerse': card = null; openReader(+d.b, +d.c, +d.v, d.id || null); break;
    case 'openCh': openReader(+d.b, +d.c, 0, d.id || null); break;
    case 'sugg': searchVal = ''; blurSearch(); openReader(+d.b, +d.c, +d.v); break;
    case 'clearHist':
      modal('<div class="mbox"><h3>Verlauf leeren?</h3><p class="muted">Alle zuletzt gelesenen Stellen werden entfernt.</p><div class="btns"><button class="c dark" data-a="clearHistOk">Leeren</button><button class="c" data-a="closeModal">Abbrechen</button></div></div>');
      break;
    case 'clearHistOk': closeModal(); S.history = []; save(); renderMain(); break;
    case 'clearQ':
      searchVal = ''; searchActive = true; renderMain();
      x = $('#q'); if (x) x.focus();
      break;
    case 'mic':
      searchActive = true; renderMain();
      x = $('#q'); if (x) { x.focus(); }
      break;
    case 'tile':
      if (lpFired) { lpFired = false; return; }
      showPinCard(+d.i); break;
    case 'tileOpen': closeModal(); if (menuCtx) openFromList(menuCtx.i); break;
    case 'tilePin':
      closeModal();
      if (menuCtx && S.marks[menuCtx.i]) {
        x = S.marks[menuCtx.i]; x.pin = !x.pin; save(); renderMain(); toast(x.pin ? 'Oben angeheftet' : 'Gelöst');
      }
      break;
    case 'tileColl':
      closeModal();
      if (menuCtx && S.marks[menuCtx.i]) { x = S.marks[menuCtx.i]; addDialog({b:x.b, c:x.c, v:x.v, bid:x.bid}); }
      break;
    case 'tileDel':
      closeModal();
      if (menuCtx) { S.marks.splice(menuCtx.i, 1); save(); renderMain(); toast('Entfernt'); }
      break;
    /* Leser */
    case 'rClose': hideOv('reader'); renderMain(); if (topOv() === 'andacht') renderAndacht(); break;
    case 'rBooks': R.menu = R.menu === 'books' ? null : 'books'; R.bsel = R.scope ? R.scope.b : null; R.tst = R.b >= 39 ? 1 : 0; renderReader(); break;
    case 'tst': R.tst = +d.t; renderReader(); break;
    case 'rBooksClose': R.menu = null; R.bsel = null; renderReader(); break;
    case 'bookPick': if (lpFired) { lpFired = false; return; } R.bsel = +d.b; R.tst = R.bsel >= 39 ? 1 : 0; renderReader(); break;
    case 'bookBack': R.bsel = null; renderReader(); break;
    case 'chapPick': if (lpFired) { lpFired = false; return; } gotoChapter(R.bsel, +d.c, false); break;
    case 'rFont': R.menu = R.menu === 'font' ? null : 'font'; renderReader(); break;
    case 'rMenuClose': R.menu = null; renderReader(); break;
    case 'setFont': S.font = d.id; saveCfg(); save(); renderReader(); break;
    case 'setSize': S.size = d.id; saveCfg(); save(); renderReader(); break;
    case 'setMode':
      S.mode = d.id; S.focused = d.id === 'focus';
      if (S.focused && R.sel.length) R.idx = R.sel[0];
      if (!S.focused) R.sel = [];
      if (d.id === 'page') { R.menu = null; R.pmenu = false; R.pkey = null; }
      saveCfg(); save(); renderReader(d.id === 'scroll'); fsSync(); break;
    case 'togVn': S.showVn = !S.showVn; save(); renderReader(); break;
    case 'togCh': S.showCh = !S.showCh; save(); renderReader(); break;
    case 'rDark': S.dark = !S.dark; save(); applyTheme(); renderReader(); break;
    case 'chNext': chapStep(1); break;
    case 'pgPrev': pageMove(-1); break;
    case 'pgNext': pageMove(1); break;
    case 'vsel':
      i = +d.i; x = R.sel.indexOf(i);
      if (x >= 0) R.sel.splice(x, 1); else { R.sel.push(i); R.sel.sort(function (a, b) { return a - b; }); }
      renderReader(); break;
    case 'selClear': R.sel = []; renderReader(); break;
    case 'rShare': openShare(); break;
    case 'shClose': hideOv('share'); break;
    case 'shCopy': copyShare(false); break;
    case 'shSend': sendShare(); break;
    case 'shSave': saveShare(); break;
    case 'cmtSave':
      x = target();
      if (x) {
        var val = $('#cmt').value.trim(), k = nkey(x.b, x.c, x.v);
        if (val) S.notes[k] = val; else delete S.notes[k];
        save();
      }
      closeModal(); renderReader(); break;
    case 'cmtDel':
      x = target(); if (x) { delete S.notes[nkey(x.b, x.c, x.v)]; save(); }
      closeModal(); renderReader(); break;
    case 'rMark': toggleMark(); if (!S.focused) renderReader(); break;
    case 'rAdd':
      x = targets(); if (!x.length) break;
      addDialog(x.map(function (t) { return {b:t.b, c:t.c, v:t.v, bid:S.bible}; })); break;
    case 'rTrans': switchBible(d.id); break;
    case 'addPick': x = findAndacht(d.id); closeModal(); if (x) addVerseTo(x); break;
    case 'addNew':
      modal('<div class="mbox"><h3>Neue Sammlung</h3><input class="field" id="newTitle" placeholder="Thema, z. B. Vertrauen"><div class="btns">' +
        '<button class="dark" data-a="addNewOk">Anlegen</button><button class="c" data-a="closeModal">Abbrechen</button></div></div>');
      break;
    case 'addNewOk':
      x = newAndacht(); x.title = ($('#newTitle').value || '').trim(); addVerseTo(x); closeModal();
      break;
    /* Andachten */
    case 'newAndacht': x = newAndacht(); openAndacht(x.id, true); break;
    case 'andachtOpen':
      if (lpFired) { lpFired = false; return; }
      x = findAndacht(d.id);
      if (x && x.plan.length === 1 && !x.verses.length) openPlan(x.plan[0], x.title); else openAndacht(d.id, false);
      break;
    case 'cvOpen': if (lpFired) { lpFired = false; return; } A.card = +d.i; renderAndacht(); break;
    case 'cvClose': A.card = null; renderAndacht(); break;
    case 'cvStep': A.card = null; renderAndacht(); openStepper(A.id, +d.i); break;
    case 'aRead': openStepper(A.id, 0); break;
    case 'planOpen': x = findAndacht(A.id); if (x && x.plan[+d.i]) openPlan(x.plan[+d.i], x.title); break;
    case 'aRemP': x = findAndacht(A.id); if (x) { x.plan.splice(+d.i, 1); save(); renderAndacht(); } break;
    case 'acOpen': closeModal(); openAndacht(menuCtx.id, false); break;
    case 'acEdit': closeModal(); openAndacht(menuCtx.id, true); break;
    case 'acDel': closeModal(); A = {id:menuCtx.id, edit:false}; act('aDel', {}, null); break;
    case 'aClose': x = findAndacht(A.id); if (x && !String(x.title).trim()) { x.title = 'Sammlung'; save(); } hideOv('andacht'); renderMain(); break;
    case 'aEdit': A.edit = true; renderAndacht(); break;
    case 'aDone': x = findAndacht(A.id); if (x && !String(x.title).trim()) x.title = 'Sammlung'; A.edit = false; save(); renderAndacht(); break;
    case 'aRemV': x = findAndacht(A.id); if (x) { x.verses.splice(+d.i, 1); save(); renderAndacht(); } break;
    case 'aDel':
      modal('<div class="mbox"><h3>Sammlung löschen?</h3><p class="muted">Das kann nicht rückgängig gemacht werden.</p><div class="btns">' +
        '<button class="dark" data-a="aDelOk">Löschen</button><button class="c" data-a="closeModal">Abbrechen</button></div></div>');
      break;
    case 'aDelOk':
      S.andachten = S.andachten.filter(function (z) { return z.id !== A.id; });
      save(); closeModal(); hideOv('andacht'); renderMain(); break;
    /* Stepper */
    case 'stPrev': stStep(-1); break;
    case 'stNext': stStep(1); break;
    case 'stClose': hideOv('stepper'); break;
    /* Profil */
    case 'nameEdit':
      modal('<div class="mbox"><h3>Dein Name</h3><input class="field" id="nameIn" value="' + esc(S.name) + '"><div class="btns">' +
        '<button class="dark" data-a="nameSave">Speichern</button><button class="c" data-a="closeModal">Abbrechen</button></div></div>');
      break;
    case 'nameSave': x = $('#nameIn').value.trim(); if (x) { S.name = x; save(); } closeModal(); renderMain(); break;
    case 'imgPick': closeModal(); $('#fileImg').click(); break;
    case 'importBible':
      closeModal();
      modal('<div class="mbox"><h3>Bibel importieren</h3><p>Wähle eine Datei im JSON-Format mit 66 Büchern (1. Mose bis Offenbarung). Aufbau: eine Liste von Büchern, jedes Buch eine Liste von Kapiteln, jedes Kapitel eine Liste von Versen (Text). Beispiel: [[["Vers 1","Vers 2"]], …]</p><p class="muted">Importiere nur Texte, für die du die Rechte hast.</p><div class="btns"><button class="c dark" data-a="importGo">Datei wählen</button><button class="c" data-a="closeModal">Abbrechen</button></div></div>');
      break;
    case 'importGo': closeModal(); $('#fileBible').click(); break;
    case 'info': closeModal(); openInfo(d.id); break;
    case 'infoClose': hideOv('info'); break;
    case 'wipeAsk':
      modal('<div class="mbox"><h3>Alle Daten löschen?</h3><p>Name, Profilbild, Gemerktes, Sammlungen, Verlauf und importierte Bibeln werden von diesem Gerät gelöscht.</p><div class="btns"><button class="c dark" data-a="wipeGo">Alles löschen</button><button class="c" data-a="closeModal">Abbrechen</button></div></div>');
      break;
    case 'wipeGo':
      try { SLOTS.forEach(function (x) { if (window.Android && Android.deleteBible) Android.deleteBible(x.id); }); } catch (e) {}
      try { localStorage.removeItem('fb'); } catch (e) {}
      location.reload(); break;
    case 'slotPick':
      closeModal();
      if (!pending) break;
      var ok = false;
      try { ok = window.Android ? Android.saveBible(d.id, pending) : false; } catch (e) { ok = false; }
      if (!ok && !window.Android) { cache[d.id] = toDense(JSON.parse(pending)); ok = true; }
      else delete cache[d.id];
      pending = null;
      if (ok) { toast('Importiert: ' + slot(d.id).name); if (!stack.length) renderMain(); else if (topOv() === 'reader') renderReader(); }
      else toast('Speichern fehlgeschlagen');
      break;
  }
}

/* ---------- Ereignisse ---------- */
var lpTimer = null, lpFired = false, lpX = 0, lpY = 0;
function acardMenu(el) {
  var id = el.getAttribute('data-id'); if (!findAndacht(id)) return;
  menuCtx = {id:id};
  var r = el.getBoundingClientRect(), u = window.innerWidth / 369;
  var left = Math.min(r.left, window.innerWidth - 246.5 * u - 4);
  var top = Math.max(4, Math.min(r.top - 4 * u, window.innerHeight - 180 * u - 8));
  modal('<div class="ctxmenu" style="left:' + left + 'px;top:' + top + 'px">' +
    '<button data-a="acOpen">Öffnen</button><button data-a="acEdit">Bearbeiten</button><button data-a="acDel">Löschen</button></div>', true);
}
var hadSel = false;
document.addEventListener('pointerdown', function (e) {
  lpFired = false;
  hadSel = !!(window.getSelection && String(window.getSelection()).length);
  var t = e.target.closest ? e.target.closest('.tile, .acard, .gbooks button, .gchap button') : null;
  if (!t) return;
  lpX = e.clientX; lpY = e.clientY;
  clearTimeout(lpTimer);
  lpTimer = setTimeout(function () {
    lpFired = true; lpTimer = null;
    if (t.classList.contains('tile')) tileMenu(t);
    else if (t.classList.contains('acard')) acardMenu(t);
    else if (t.hasAttribute('data-b')) addDialog([{t:'b', b:+t.getAttribute('data-b')}]);
    else addDialog([{t:'c', b:R.bsel, c:+t.getAttribute('data-c')}]);
  }, 550);
});
document.addEventListener('pointermove', function (e) {
  if (lpTimer && (Math.abs(e.clientX - lpX) > 10 || Math.abs(e.clientY - lpY) > 10)) { clearTimeout(lpTimer); lpTimer = null; }
});
['pointerup', 'pointercancel'].forEach(function (ev) {
  document.addEventListener(ev, function () { clearTimeout(lpTimer); lpTimer = null; });
});
var scTimer = null;
document.addEventListener('scroll', function (e) {
  var rb = e.target;
  if (!rb || rb.id !== 'rbody' || S.mode !== 'scroll' || topOv() !== 'reader') return;
  clearTimeout(scTimer);
  scTimer = setTimeout(function () {
    var vps = rb.querySelectorAll('.vp,.fv'), top = rb.getBoundingClientRect().top, k = 0;
    for (var j = 0; j < vps.length; j++) { if (vps[j].getBoundingClientRect().bottom > top + 6) { k = j; break; } }
    if (rb.scrollTop + rb.clientHeight >= rb.scrollHeight - 4) k = Math.max(0, vps.length - 1);
    R.idx = k; trackPos(k);
  }, 250);
}, true);
document.addEventListener('mousedown', function (e) {
  if (e.target.closest && e.target.closest('.sugg, [data-a=clearQ]')) e.preventDefault();
});
document.addEventListener('contextmenu', function (e) { if (!(e.target.closest && e.target.closest('#pager'))) e.preventDefault(); });

document.addEventListener('click', function (e) {
  var tg = e.target;
  if (startPanel === 'trans' && tg.closest && !tg.closest('.dd')) { startPanel = null; renderMain(); return; }
  if (tg.id === 'q') {
    if (searchActive) return;
    if (startPanel !== 'history') { startPanel = 'history'; renderMain(); }
    else {
      searchActive = true; renderMain();
      var q = $('#q'); q.focus();
      try { q.setSelectionRange(q.value.length, q.value.length); } catch (x) {}
    }
    return;
  }
  if (topOv() === 'reader' && S.mode === 'page' && !R.menu && $('#modal').hidden && tg.closest && tg.closest('#pager')) {
    var sel = window.getSelection && window.getSelection();
    if (hadSel || (sel && String(sel).length)) { hadSel = false; if (sel) sel.removeAllRanges(); return; }
    var fx = e.clientX / window.innerWidth;
    if (R.pmenu) { R.pmenu = false; $('#pgbar').hidden = true; $('#pgfoot').hidden = true; }
    else if (fx < 0.3) pageMove(-1);
    else if (fx > 0.7) pageMove(1);
    else { R.pmenu = true; $('#pgbar').hidden = false; $('#pgfoot').hidden = false; }
    return;
  }
  if (topOv() === 'reader' && S.focused && !R.menu && $('#modal').hidden && tg.closest && tg.closest('#rbody') && !tg.closest('[data-a]')) {
    if (e.clientX < window.innerWidth * 0.35) prevVerse(); else nextVerse();
    return;
  }
  var t = tg.closest ? tg.closest('[data-a]') : null;
  if (!t) return;
  act(t.getAttribute('data-a'), {
    t:t.getAttribute('data-t'), id:t.getAttribute('data-id'), b:t.getAttribute('data-b'), c:t.getAttribute('data-c'),
    v:t.getAttribute('data-v'), i:t.getAttribute('data-i'), k:t.getAttribute('data-k')
  }, t);
});

document.addEventListener('keydown', function (e) {
  if (e.target.id === 'q' && (e.key === 'Enter' || e.keyCode === 13)) {
    e.preventDefault();
    var v = e.target.value; e.target.blur();
    doSearch(v);
  }
});
document.addEventListener('input', function (e) {
  var t = e.target, a;
  if (t.id === 'q') { searchVal = t.value; syncQBtn(); applySugg(); return; }
  if (t.id === 'slider') { R.idx = parseInt(t.value, 10) - 1; updateFocused(); return; }
  if (A.id && t.id === 'aTitle') {
    a = findAndacht(A.id); if (!a) return;
    a.title = t.value; save();
  }
});
document.addEventListener('focusout', function (e) {
  if (e.target.id === 'q' && e.target.isConnected) { searchActive = false; e.target.readOnly = true; updateTyping(); }
});
$('#fileBible').addEventListener('change', function (e) {
  var f = e.target.files && e.target.files[0]; e.target.value = '';
  if (f) handleBibleFile(f);
});
$('#fileImg').addEventListener('change', function (e) {
  var f = e.target.files && e.target.files[0]; e.target.value = '';
  if (f) handleImage(f);
});

/* Wischgesten */
var tx = 0, ty = 0, tt = 0;
document.addEventListener('touchstart', function (e) {
  var t = e.touches[0]; tx = t.clientX; ty = t.clientY; tt = Date.now();
}, {passive:true});
document.addEventListener('touchend', function (e) {
  if (!$('#modal').hidden) return;
  var t = e.changedTouches[0], dx = t.clientX - tx, dy = t.clientY - ty, tg = e.target;
  if (Math.abs(dx) < 70 * (window.innerWidth / 369) / 1.3 || Math.abs(dy) > Math.abs(dx) * 0.6 || Date.now() - tt > 900) return;
  if (tg.closest && tg.closest('input,textarea')) return;
  var left = dx < 0, top = topOv();
  if (top === 'reader') {
    if (R.menu) return;
    if (S.focused && RV.length) { if (left) nextVerse(); else prevVerse(); }
    else if (S.mode === 'page') pageMove(left ? 1 : -1);
    else chapStep(left ? 1 : -1);
  } else if (top === 'stepper') {
    stStep(left ? 1 : -1);
  } else if (!top && tab === 'start' && !card && tg.closest && tg.closest('#body')) {
    openReader(S.last.b, S.last.c);
  }
}, {passive:true});

/* Lautstärketasten: leiser = weiter, lauter = zurück (nur im Leser / bei "Verse lesen") */
window.appVolume = function (d) {
  var top = topOv();
  if (top === 'stepper') { stStep(d); return true; }
  if (top !== 'reader' || R.menu || !$('#modal').hidden) return false;
  if (S.focused && RV.length) { if (d > 0) nextVerse(); else prevVerse(); return true; }
  if (S.mode === 'page') { pageMove(d > 0 ? 1 : -1); return true; }
  var rb = $('#rbody');
  if (rb) rb.scrollTop += d * rb.clientHeight * 0.85;
  return true;
};

/* Zurück-Taste von Android */
window.appBack = function () {
  if (!$('#modal').hidden) { closeModal(); return true; }
  var top = topOv();
  if (top) {
    if (top === 'reader' && S.mode === 'page' && R.pmenu && !R.menu) { R.pmenu = false; $('#pgbar').hidden = true; $('#pgfoot').hidden = true; return true; }
    if (top === 'reader' && R.menu) {
      if (R.menu === 'books' && R.bsel != null) R.bsel = null; else R.menu = null;
      renderReader(); return true;
    }
    hideOv(top);
    if (!stack.length) renderMain();
    return true;
  }
  if (card || startPanel) { card = null; startPanel = null; renderMain(); return true; }
  if (tab !== 'start') { setTab('start'); return true; }
  return false;
};

var rsT = null;
window.addEventListener('resize', function () {
  clearTimeout(rsT);
  rsT = setTimeout(function () { if (topOv() === 'reader' && S.mode === 'page' && !R.menu && $('#pager')) renderReader(); }, 200);
});
loadCfg(false);
applyTheme();
applyReadStyle();
renderMain();
})();
