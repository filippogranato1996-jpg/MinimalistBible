(function () {
'use strict';

/* ---------- Stammdaten ---------- */
var DE = ['1. Mose','2. Mose','3. Mose','4. Mose','5. Mose','Josua','Richter','Ruth','1. Samuel','2. Samuel','1. Könige','2. Könige','1. Chronik','2. Chronik','Esra','Nehemia','Esther','Hiob','Psalm','Sprüche','Prediger','Hoheslied','Jesaja','Jeremia','Klagelieder','Hesekiel','Daniel','Hosea','Joel','Amos','Obadja','Jona','Micha','Nahum','Habakuk','Zephanja','Haggai','Sacharja','Maleachi','Matthäus','Markus','Lukas','Johannes','Apostelgeschichte','Römer','1. Korinther','2. Korinther','Galater','Epheser','Philipper','Kolosser','1. Thessalonicher','2. Thessalonicher','1. Timotheus','2. Timotheus','Titus','Philemon','Hebräer','Jakobus','1. Petrus','2. Petrus','1. Johannes','2. Johannes','3. Johannes','Judas','Offenbarung'];
var EN = ['Genesis','Exodus','Leviticus','Numbers','Deuteronomy','Joshua','Judges','Ruth','1 Samuel','2 Samuel','1 Kings','2 Kings','1 Chronicles','2 Chronicles','Ezra','Nehemiah','Esther','Job','Psalms','Proverbs','Ecclesiastes','Song of Solomon','Isaiah','Jeremiah','Lamentations','Ezekiel','Daniel','Hosea','Joel','Amos','Obadiah','Jonah','Micah','Nahum','Habakkuk','Zephaniah','Haggai','Zechariah','Malachi','Matthew','Mark','Luke','John','Acts','Romans','1 Corinthians','2 Corinthians','Galatians','Ephesians','Philippians','Colossians','1 Thessalonians','2 Thessalonians','1 Timothy','2 Timothy','Titus','Philemon','Hebrews','James','1 Peter','2 Peter','1 John','2 John','3 John','Jude','Revelation'];
var IT = ['Genesi','Esodo','Levitico','Numeri','Deuteronomio','Giosuè','Giudici','Rut','1 Samuele','2 Samuele','1 Re','2 Re','1 Cronache','2 Cronache','Esdra','Neemia','Ester','Giobbe','Salmi','Proverbi','Ecclesiaste','Cantico dei Cantici','Isaia','Geremia','Lamentazioni','Ezechiele','Daniele','Osea','Gioele','Amos','Abdia','Giona','Michea','Naum','Abacuc','Sofonia','Aggeo','Zaccaria','Malachia','Matteo','Marco','Luca','Giovanni','Atti','Romani','1 Corinzi','2 Corinzi','Galati','Efesini','Filippesi','Colossesi','1 Tessalonicesi','2 Tessalonicesi','1 Timoteo','2 Timoteo','Tito','Filemone','Ebrei','Giacomo','1 Pietro','2 Pietro','1 Giovanni','2 Giovanni','3 Giovanni','Giuda','Apocalisse'];
var CH = [50,40,27,36,34,24,21,4,31,24,22,25,29,36,10,13,10,42,150,31,12,8,66,52,5,48,12,14,3,9,1,4,7,3,3,3,2,14,4,28,16,24,21,28,16,16,13,6,6,4,4,5,3,6,4,3,1,13,5,5,3,5,1,1,1,22];
var SLOTS = [
  {id:'schlachter', name:'Schlachter 1951', short:'Schlachter', lang:'de'},
  {id:'bsb', name:'Berean Standard Bible', short:'BSB', lang:'en'},
  {id:'riveduta', name:'Riveduta 1990', short:'Riveduta', lang:'it'}
];
var GROUPS = [['de','DEUTSCH'],['en','ENGLISH'],['it','ITALIANO']];
var FONTS = [
  {id:'sourceserif', name:'Source Serif', css:"'Source Serif 4',Georgia,serif"},
  {id:'playfair', name:'Playfair', css:"'Playfair',Georgia,serif"},
  {id:'lora', name:'Lora', css:"'Lora',Georgia,serif"},
  {id:'merriweather', name:'Merriweather', css:"'Merriweather',Georgia,serif"},
  {id:'crimson', name:'Crimson', css:"'Crimson Pro',Georgia,serif"},
  {id:'garamond', name:'EB Garamond', css:"'EB Garamond',Georgia,serif"},
  {id:'cormorant', name:'Cormorant', css:"'Cormorant Garamond',Georgia,serif"},
  {id:'inter', name:'Inter', css:"'Inter',Arial,sans-serif"},
  {id:'georgia', name:'Georgia', css:"Georgia,'Times New Roman',serif"}
];
var SIZES = {S:20, M:24, L:28, XL:32};
var MONTHS = ['JAN.','FEB.','MÄR.','APR.','MAI','JUN.','JUL.','AUG.','SEP.','OKT.','NOV.','DEZ.'];

/* ---------- Helfer ---------- */
function $(s) { return document.querySelector(s); }
function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) {
    return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];
  });
}
/* Lucide-ähnliche Symbole (24er-Raster) */
var ICON = {
  home:['M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8','M3 10a2 2 0 0 1 .709-1.528l7-5.999a2 2 0 0 1 2.582 0l7 5.999A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z'],
  pin:['M12 17v5','M9 10.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V7a1 1 0 0 1 1-1 2 2 0 0 0 0-4H8a2 2 0 0 0 0 4 1 1 0 0 1 1 1z'],
  book:['M12 7v14','M3 18a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h5a4 4 0 0 1 4 4 4 4 0 0 1 4-4h5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-6a3 3 0 0 0-3 3 3 3 0 0 0-3-3z'],
  bookm:['M10 2v8l3-3 3 3V2','M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20'],
  search:['M21 21l-4.34-4.34','M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16z'],
  mic:['M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z','M19 10v2a7 7 0 0 1-14 0v-2','M12 19v3'],
  shuffle:['M2 18h1.4c1.3 0 2.5-.6 3.3-1.7l6.1-8.6c.7-1.1 2-1.7 3.3-1.7H22','m18 2 4 4-4 4','M2 6h1.9c1.5 0 2.9.9 3.6 2.2','M22 18h-5.9c-1.3 0-2.6-.7-3.3-1.8l-.5-.8','m18 14 4 4-4 4'],
  x:['M18 6 6 18','m6 6 12 12'],
  down:['m6 9 6 6 6-6'],
  left:['m15 18-6-6 6-6'],
  right:['m9 18 6-6-6-6'],
  comment:['M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z'],
  heart:['M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z'],
  plus:['M5 12h14','M12 5v14'],
  trash:['M3 6h18','M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6','M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2','M10 11v6','M14 11v6'],
  play:['m6 3 14 9-14 9z'],
  folder:['M12 10v6','M9 13h6','M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z'],
  history:['M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8','M3 3v5h5','M12 7v5l4 2'],
  check:['M20 6 9 17l-5-5'],
  camera:['M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z','M12 16a3 3 0 1 0 0-6 3 3 0 0 0 0 6z'],
  pencil:['M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z'],
  upload:['M12 3v12','m17 8-5-5-5 5','M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4']
};
function ic(n, cls, fill) {
  return '<svg class="ic ' + (cls || '') + '" viewBox="0 0 24 24"' + (fill ? ' style="fill:currentColor"' : '') + '>' +
    ICON[n].map(function (d) { return '<path d="' + d + '"/>'; }).join('') + '</svg>';
}
function rnd(n) { return Math.floor(Math.random() * n); }
function toast(msg) {
  var t = $('#toast');
  t.textContent = msg; t.hidden = false;
  clearTimeout(toast.t);
  toast.t = setTimeout(function () { t.hidden = true; }, 1800);
}
function fmtDate(ts) {
  var d = new Date(ts);
  return d.getDate() + '. ' + MONTHS[d.getMonth()];
}

/* ---------- Zustand ---------- */
function defaults() {
  return { bible:'schlachter', last:{b:42, c:3}, history:[], pins:[], marks:[], notes:{},
           andachten:[], font:'sourceserif', size:'M', focused:true, name:'Filippo Granato', img:'' };
}
var S = (function () {
  var s = null;
  try { s = JSON.parse(localStorage.getItem('fb')); } catch (e) {}
  s = (s && typeof s === 'object') ? Object.assign(defaults(), s) : defaults();
  if (!FONTS.some(function (f) { return f.id === s.font; })) s.font = 'sourceserif';
  if (!SIZES[s.size]) s.size = 'M';
  var MAP = {luther1912:'schlachter', elberfelder:'schlachter', kjv:'bsb', diodati:'riveduta'};
  var mb = function (id) { return MAP[id] || id; };
  s.bible = mb(s.bible);
  if (!SLOTS.some(function (x) { return x.id === s.bible; })) s.bible = 'schlachter';
  ['history', 'marks', 'pins'].forEach(function (k) { (s[k] || []).forEach(function (x) { if (x.bid) x.bid = mb(x.bid); }); });
  (s.andachten || []).forEach(function (a) { (a.verses || []).forEach(function (v) { if (v.bid) v.bid = mb(v.bid); }); });
  if (s.pins && s.pins.length) {
    s.pins.forEach(function (p) { p.pin = true; });
    s.marks = s.pins.concat(s.marks.filter(function (m) {
      return !s.pins.some(function (p) { return p.b === m.b && p.c === m.c && p.v === m.v && p.bid === m.bid; });
    }));
  }
  s.pins = [];
  return s;
})();
function save() { try { localStorage.setItem('fb', JSON.stringify(S)); } catch (e) {} }

function slot(id) {
  for (var i = 0; i < SLOTS.length; i++) if (SLOTS[i].id === id) return SLOTS[i];
  return SLOTS[0];
}
function lang(id) { return slot(id || S.bible).lang; }
function bname(b, bid) { var l = lang(bid); return (l === 'de' ? DE : l === 'it' ? IT : EN)[b]; }
function fmtRef(b, c, v, bid) {
  return bname(b, bid) + ' ' + c + (v ? (lang(bid) === 'de' ? ',' : ':') + v : '');
}
function nkey(b, c, v) { return b + '.' + c + '.' + v; }

/* ---------- Bibeltexte ---------- */
var cache = {};
function toDense(raw) {
  if (Array.isArray(raw)) return raw.map(function (x) { return x.chapters || x; });
  if (raw && raw.books) return raw.books.map(function (x) { return x.chapters || x; });
  return null;
}
function fromSample(list) {
  var bk = [];
  list.forEach(function (r) {
    bk[r[0]] = bk[r[0]] || [];
    bk[r[0]][r[1] - 1] = bk[r[0]][r[1] - 1] || [];
    bk[r[0]][r[1] - 1][r[2] - 1] = r[3];
  });
  return bk;
}
function bible(id) {
  if (id in cache) return cache[id];
  var d = null;
  try {
    if (window.Android && Android.hasBible(id)) {
      d = toDense(JSON.parse(String(Android.readBible(id)).replace(/^﻿/, '')));
    }
  } catch (e) { d = null; }
  if (!d && window.SAMPLE && SAMPLE[id]) d = fromSample(SAMPLE[id]);
  cache[id] = d;
  return d;
}
function isFull(id) {
  var d = bible(id);
  return !!(d && d.length >= 66 && d[0] && d[65]);
}
function nch(b, bid) {
  var d = bible(bid || S.bible);
  return d && d[b] && d[b].length ? d[b].length : CH[b];
}
function totalCh() { var t = 0; for (var b = 0; b < 66; b++) t += nch(b); return t; }
function chapter(id, b, c) {
  var d = bible(id), ch = d && d[b] && d[b][c - 1], out = [];
  if (!ch) return out;
  for (var i = 0; i < ch.length; i++) {
    if (ch[i] != null && ch[i] !== '') out.push({n: i + 1, t: String(ch[i])});
  }
  return out;
}
function verseText(id, b, c, v) {
  var d = bible(id), t = d && d[b] && d[b][c - 1] && d[b][c - 1][v - 1];
  return t ? String(t) : null;
}
function anyText(b, c, v, pref) {
  var first = pref || S.bible;
  var order = [first];
  SLOTS.forEach(function (s) { if (s.lang === lang(first) && order.indexOf(s.id) < 0) order.push(s.id); });
  SLOTS.forEach(function (s) { if (order.indexOf(s.id) < 0) order.push(s.id); });
  for (var i = 0; i < order.length; i++) {
    var t = verseText(order[i], b, c, v);
    if (t) return {t: t, bid: order[i]};
  }
  return null;
}
function pool() {
  var p = REFS.filter(function (r) { return verseText(S.bible, r[0], r[1], r[2]); });
  if (p.length) return p;
  p = REFS.filter(function (r) { return anyText(r[0], r[1], r[2]); });
  return p.length ? p : REFS;
}
function votdRef() {
  var p = pool(), n = new Date();
  var day = Math.floor(Date.UTC(n.getFullYear(), n.getMonth(), n.getDate()) / 864e5);
  var r = p[day % p.length];
  return {kind:'votd', b:r[0], c:r[1], v:r[2]};
}
function randomRef(prev) {
  var id = S.bible;
  if (isFull(id)) {
    for (var k = 0; k < 80; k++) {
      var g = rnd(totalCh()), b = 0;
      while (b < 65 && g >= nch(b)) { g -= nch(b); b++; }
      var vs = chapter(id, b, g + 1);
      if (vs.length) return {kind:'random', b:b, c:g + 1, v:vs[rnd(vs.length)].n};
    }
  }
  var p = pool(), r;
  for (var t = 0; t < 12; t++) {
    r = p[rnd(p.length)];
    if (!prev || p.length < 2 || r[0] !== prev.b || r[1] !== prev.c || r[2] !== prev.v) break;
  }
  return {kind:'random', b:r[0], c:r[1], v:r[2]};
}

/* ---------- Navigation ---------- */
var tab = 'start', startPanel = null, card = null, searchVal = '', searchActive = false;
var stack = [];
function syncVol() {
  var t = topOv();
  try { if (window.Android && Android.setVolumeNav) Android.setVolumeNav(t === 'reader' || t === 'stepper'); } catch (e) {}
}
function showOv(name) {
  var el = $('#' + name);
  el.hidden = false;
  var i = stack.indexOf(name); if (i >= 0) stack.splice(i, 1);
  stack.push(name);
  el.style.zIndex = 10 + stack.length;
  syncVol();
}
function hideOv(name) {
  $('#' + name).hidden = true;
  var i = stack.indexOf(name); if (i >= 0) stack.splice(i, 1);
  syncVol();
}
function topOv() { return stack[stack.length - 1]; }

function modal(html, transparent) {
  var m = $('#modal');
  m.innerHTML = '<div class="mbg" data-a="closeModal"' + (transparent ? ' style="background:transparent"' : '') + '></div>' + html;
  m.hidden = false;
}
function closeModal() { var m = $('#modal'); m.hidden = true; m.innerHTML = ''; }

/* ---------- Hauptansicht ---------- */
function setTab(t) { tab = t; card = null; startPanel = null; searchActive = false; renderMain(); }

function renderMain() {
  var av = $('#avatar');
  if (S.img) av.innerHTML = '<img alt="" src="' + esc(S.img) + '">';
  else {
    var ini = S.name.split(/\s+/).map(function (w) { return w.charAt(0); }).join('').slice(0, 2).toUpperCase();
    av.textContent = ini || '?';
  }
  var b = $('#body');
  b.innerHTML = (tab === 'start' ? viewStart() : tab === 'marks' ? viewMarks() : viewAndachten()) + (card ? cardHtml(card) : '');
  b.style.overflowY = card ? 'hidden' : 'auto';
  if (card) b.scrollTop = 0;
  var tabs = [['start','home','Start'],['marks','heart','Gemerkt'],['andachten','book','Sammlung']];
  if (tab === 'start' && !card) applySugg();
  $('#nav').innerHTML = tabs.map(function (t) {
    return '<button data-a="tab" data-t="' + t[0] + '" class="' + (tab === t[0] ? 'on' : '') + '">' + ic(t[1]) + '<span class="cap">' + t[2] + '</span></button>';
  }).join('');
}

function viewStart() {
  var h = '<div class="start' + (startPanel === 'history' ? ' h' : '') + '"><div class="art"></div>' +
    '<div class="trow"><span class="lbl t1">Übersetzung</span><button class="sel" data-a="trans">' +
    esc(slot(S.bible).name) + ic('down') + '</button></div>';
  h += '<div class="srow"><div class="search">' + ic('search') +
    '<input id="q" type="text" value="' + esc(searchVal) + '" placeholder="Psalm 23, Römer 8 …" autocomplete="off" enterkeyhint="search"' +
    (searchActive ? '' : ' readonly') + '>' +
    '<span data-a="mic" style="display:flex">' + ic('mic', 'mic') + '</span></div>' +
    '<button class="sq" data-a="random" aria-label="Zufälliger Vers">' + ic('shuffle') + '</button></div>' +
    '<div class="hist sugg" id="sugg" style="display:none"></div><div id="below">';
  if (startPanel === 'history') {
    h += '<div class="hist"><div class="hh"><span class="lbl">' + ic('history') + 'Zuletzt gelesen</span>' +
      '<button data-a="clearHist">' + ic('trash') + 'Leeren</button></div>';
    if (!S.history.length) h += '<div class="none">Noch nichts gelesen.</div>';
    S.history.forEach(function (x) {
      h += '<button class="row" data-a="openCh" data-id="' + (x.bid || '') + '" data-b="' + x.b + '" data-c="' + x.c + '"><b>' +
        esc(bname(x.b, x.bid) + ' ' + x.c) + '</b><small>' + fmtDate(x.t) + '</small>' + ic('book') + '</button>';
    });
    h += '</div>';
  } else {
    var r = votdRef();
    h += '<button class="votd" data-a="votd"><span class="lbl">Vers des Tages</span><b>' + esc(fmtRef(r.b, r.c, r.v)) + '</b></button>';
  }
  h += '</div></div>';
  if (startPanel === 'trans') {
    h += '<div class="dd">';
    GROUPS.forEach(function (g) {
      h += '<span class="lbl">' + g[1] + '</span><div class="grp">';
      SLOTS.filter(function (s) { return s.lang === g[0]; }).forEach(function (s) {
        h += '<button class="opt ' + (s.id === S.bible ? 'on' : '') + '" data-a="setBible" data-id="' + s.id + '">' +
          '<span>' + esc(s.name) + '</span>' + (s.id === S.bible ? ic('check') : '') + '</button>';
      });
      h += '</div>';
    });
    h += '</div>';
  }
  return h;
}

/* Karte: kind = votd | random | pins | marks */
function cardHtml(r) {
  var got = anyText(r.b, r.c, r.v, r.bid), ref = fmtRef(r.b, r.c, r.v, r.bid);
  var body = got
    ? '„' + esc(got.t) + '"' + (got.bid !== S.bible ? '<div class="src">' + esc(slot(got.bid).name) + '</div>' : '')
    : '<span class="muted" style="font-family:var(--sans);font-size:calc(14 * var(--u))">Der Text ist in dieser Übersetzung nicht eingebaut. Wechsle die Übersetzung auf der Startseite.</span>';
  var lbl = r.kind === 'votd' ? 'Vers des Tages' : r.kind === 'random' ? 'Zufälliger Vers' : r.kind === 'marks' ? 'Gemerkt' : 'Angepinnt';
  var cls = r.kind === 'votd' ? 'vot' : r.kind === 'random' ? 'rnd' : 'pin';
  return '<div class="card ' + cls + '"><div class="ch"><span class="lbl">' + lbl +
    '</span><button data-a="closeCard" aria-label="Schließen">' + ic('x') + '</button></div>' +
    '<div class="cb"><div class="cref">' + esc(ref) + '</div><div class="ctext">' + body + '</div></div>' +
    '<div class="cf"><button class="primary" data-a="openVerse" data-b="' + r.b + '" data-c="' + r.c + '" data-v="' + r.v + '" data-id="' + (r.bid || '') + '">' +
    ic('book') + 'In der Bibel lesen</button></div></div>';
}

function tile(i) {
  var p = S.marks[i];
  return '<button class="tile" data-a="tile" data-i="' + i + '">' + (p.pin ? ic('pin', 'tp') : '') +
    esc(fmtRef(p.b, p.c, p.v, p.bid)) + '</button>';
}
function viewMarks() {
  var h = '<div class="pins"><h2 class="ph">' + ic('heart', 'l') + 'Gemerkt</h2>';
  if (!S.marks.length) {
    h += '<p class="empty">Noch nichts gemerkt. Öffne einen Vers im Leser und tippe auf „Merken“. Gedrückt halten öffnet das Menü.</p>';
  } else {
    var idx = S.marks.map(function (_, i) { return i; }).sort(function (a, b) {
      return ((S.marks[b].pin ? 1 : 0) - (S.marks[a].pin ? 1 : 0)) || (a - b);
    });
    h += '<div class="grid2">' + idx.map(tile).join('') + '</div>';
  }
  return h + '<div style="height:calc(22 * var(--u))"></div></div>';
}
function viewAndachten() {
  var h = '<div class="andachten"><div class="head"><h2 class="ph">' + ic('book', 'l') + '<span>Meine Sammlungen</span></h2>' +
    '<button class="new" data-a="newAndacht">' + ic('folder') + 'Neue Sammlung</button></div>';
  if (!S.andachten.length) {
    h += '<p class="empty">Noch keine Sammlung. Lege eine Themensammlung an oder füge im Leser Verse über „Zur Sammlung“ hinzu.</p>';
  } else {
    h += '<div class="grid2">' + S.andachten.map(function (a) {
      return '<button class="acard" data-a="andachtOpen" data-id="' + a.id + '">' + ic('book') +
        '<b>' + esc(a.title || 'Ohne Titel') + '</b><small>' + a.verses.length + ' Verse · ' + esc(S.name) + '</small></button>';
    }).join('') + '</div>';
  }
  return h + '<div style="height:calc(22 * var(--u))"></div></div>';
}

/* ---------- Suche ---------- */
function norm(s) {
  return s.toLowerCase().replace(/ä/g,'a').replace(/ö/g,'o').replace(/ü/g,'u').replace(/ß/g,'ss')
    .replace(/[èé]/g,'e').replace(/[àá]/g,'a').replace(/[ìí]/g,'i').replace(/[òó]/g,'o').replace(/[ùú]/g,'u')
    .replace(/[^a-z0-9]/g, '');
}
var NAMES = DE.map(function (_, i) { return [norm(DE[i]), norm(EN[i]), norm(IT[i])]; });
function findBook(q) {
  var n = norm(q), i, j;
  if (!n) return -1;
  for (i = 0; i < 66; i++) for (j = 0; j < 3; j++) if (NAMES[i][j] === n) return i;
  for (i = 0; i < 66; i++) if (NAMES[i][lang() === 'de' ? 0 : lang() === 'it' ? 2 : 1].indexOf(n) === 0) return i;
  for (i = 0; i < 66; i++) for (j = 0; j < 3; j++) if (NAMES[i][j].indexOf(n) === 0) return i;
  return -1;
}
function doSearch(str) {
  var m = String(str).match(/^\s*((?:[1-3]\s*\.?\s*)?[A-Za-zÀ-ÿ]+(?:\s+[A-Za-zÀ-ÿ]+)*)\s*(\d+)?(?:\s*[:,.]\s*(\d+))?\s*$/);
  if (!m) { toast('Nichts gefunden'); return; }
  var b = findBook(m[1]);
  if (b < 0) { toast('Buch nicht gefunden'); return; }
  var c = Math.min(Math.max(parseInt(m[2] || '1', 10), 1), nch(b));
  var v = m[3] ? parseInt(m[3], 10) : 0;
  searchVal = '';
  openReader(b, c, v);
}

/* Vorschläge beim Tippen: Bücher, Kapitel, Verse */
function matchBooks(prefix) {
  var n = norm(prefix), cur = lang() === 'de' ? 0 : lang() === 'it' ? 2 : 1, out = [], i, j;
  if (!n) return out;
  for (i = 0; i < 66; i++) if (NAMES[i][cur].indexOf(n) === 0) out.push(i);
  for (i = 0; i < 66; i++) if (out.indexOf(i) < 0) for (j = 0; j < 3; j++) if (NAMES[i][j].indexOf(n) === 0) { out.push(i); break; }
  return out;
}
function suggRows(q) {
  q = String(q || '').trim();
  var rows = [], b, c, i, books;
  if (!q) return rows;
  if (/^[1-3]\s*\.?$/.test(q)) {
    books = matchBooks(q.replace(/\D/g, '')).slice(0, 5);
    books.forEach(function (bi) { rows.push({t:bname(bi), s:nch(bi) + ' Kap.', b:bi, c:1, v:0}); });
    return rows;
  }
  var m = q.match(/^((?:[1-3]\s*\.?\s*)?[A-Za-zÀ-ÿ]+(?:\s+[A-Za-zÀ-ÿ]+)*)\s*(\d+)?(?:\s*[:,.]\s*(\d*))?$/);
  if (!m) return rows;
  books = matchBooks(m[1]).slice(0, 5);
  if (m[2] === undefined) {
    books.forEach(function (bi) { rows.push({t:bname(bi), s:nch(bi) + ' Kap.', b:bi, c:1, v:0}); });
    return rows;
  }
  b = books[0]; if (b === undefined) return rows;
  var typed = m[2], max = nch(b);
  if (m[3] !== undefined) {
    c = parseInt(typed, 10); if (c < 1 || c > max) return rows;
    var vs = chapter(S.bible, b, c), vt = m[3];
    vs.filter(function (x) { return String(x.n).indexOf(vt) === 0; }).slice(0, 5).forEach(function (x) {
      rows.push({t:fmtRef(b, c, x.n), s:x.t.slice(0, 28) + '…', b:b, c:c, v:x.n});
    });
    if (!rows.length) rows.push({t:bname(b) + ' ' + c, s:'Kapitel', b:b, c:c, v:0});
    return rows;
  }
  for (i = 1; i <= max && rows.length < 5; i++) {
    if (String(i).indexOf(typed) === 0) rows.push({t:bname(b) + ' ' + i, s:'Kapitel', b:b, c:i, v:0});
  }
  return rows;
}
function applySugg() {
  var box = $('#sugg'), below = $('#below');
  if (!box) return;
  var qi = $('#q');
  var rows = (qi && !qi.readOnly) ? suggRows(searchVal) : [];
  box.innerHTML = rows.map(function (r) {
    return '<button class="row" data-a="sugg" data-b="' + r.b + '" data-c="' + r.c + '" data-v="' + r.v + '"><b>' + esc(r.t) +
      '</b><small>' + esc(r.s) + '</small>' + ic('book') + '</button>';
  }).join('');
  box.style.display = rows.length ? '' : 'none';
  if (below) below.style.display = rows.length ? 'none' : '';
}

/* ---------- Leser ---------- */
var R = {b:42, c:3, idx:0, menu:null, bsel:null, sel:null}, RV = [];

function recordRead(b, c) {
  S.last = {b:b, c:c};
  S.history = S.history.filter(function (x) { return !(x.b === b && x.c === c); });
  S.history.unshift({b:b, c:c, t:Date.now(), bid:S.bible});
  S.history = S.history.slice(0, 30);
  save();
}
function openReader(b, c, v, bid) {
  if (bid && bid !== S.bible) S.bible = bid;
  R = {b:b, c:c, idx:0, menu:null, bsel:null, sel:null};
  var vs = chapter(S.bible, b, c);
  if (v) for (var i = 0; i < vs.length; i++) if (vs[i].n === v) { R.idx = i; R.sel = i; }
  recordRead(b, c);
  showOv('reader');
  renderReader(true);
}
function applyReadStyle() {
  var f = FONTS.filter(function (x) { return x.id === S.font; })[0] || FONTS[0];
  var px = SIZES[S.size] || 24;
  var st = document.documentElement.style;
  st.setProperty('--read', f.css);
  st.setProperty('--rs', 'calc(' + px + ' * var(--u))');
  st.setProperty('--rl', 'calc(' + (px * 1.354) + ' * var(--u))');
}
function target() {
  if (!RV.length) return null;
  var i = S.focused ? R.idx : R.sel;
  if (i == null || !RV[i]) return null;
  return {b:R.b, c:R.c, v:RV[i].n};
}
function isMarked(t) {
  return S.marks.some(function (m) { return m.b === t.b && m.c === t.c && m.v === t.v && m.bid === S.bible; });
}
function actionsInner() {
  var t = target(), mk = t && isMarked(t);
  return '<button data-a="rComment">' + ic('comment') + '<span class="cap">Kommentar</span></button>' +
    '<button data-a="rMark">' + ic('heart', '', mk) + '<span class="cap">' + (mk ? 'Gemerkt' : 'Merken') + '</span></button>' +
    '<button data-a="rAdd">' + ic('folder') + '<span class="cap">Zur Sammlung</span></button>';
}
function focusVerse() {
  var v = RV[R.idx];
  if (!v) return '';
  var note = S.notes[nkey(R.b, R.c, v.n)];
  return '<div class="verse' + (isMarked({b:R.b, c:R.c, v:v.n}) ? ' mk' : '') + '"><span class="vn">' + v.n + '</span><span>' + esc(v.t) + '</span>' +
    (note ? '<div class="vnote">' + esc(note) + '</div>' : '') + '</div>';
}
function sliderPos(n) { return n > 1 ? (R.idx / (n - 1)) * 100 : 0; }
function renderReader(scrollSel) {
  var el = $('#reader'), n;
  var keep = $('#rbody') ? $('#rbody').scrollTop : 0;
  RV = chapter(S.bible, R.b, R.c); n = RV.length;
  if (R.idx >= n) R.idx = Math.max(0, n - 1);
  applyReadStyle();
  var pct = n ? Math.round((S.focused ? R.idx + 1 : 1) / n * 100) : 0;
  var h = '<div class="bar' + (R.menu === 'books' ? ' compact' : '') + '"><button class="b-fertig" data-a="rClose">Fertig</button>' +
    '<button class="grow" data-a="rBooks"><span>' + esc(bname(R.b) + ' ' + R.c) + '</span>' + ic('down') + '</button>' +
    '<button class="aA" data-a="rFont"><small>a</small>A</button></div>';
  if (R.menu === 'books') {
    el.innerHTML = h + bookPanel();
    return;
  }
  h += '<div class="prog"><i id="prog" style="width:' + pct + '%"></i></div>';
  if (!n) {
    h += '<div class="rbody" id="rbody" style="font-family:var(--sans);font-size:calc(15 * var(--u));line-height:1.5"><p class="muted">Dieses Kapitel ist in „' +
      esc(slot(S.bible).name) + '“ nicht vorhanden.</p></div>';
  } else if (S.focused) {
    h += '<div class="rbody" id="rbody">' + focusVerse() + '</div><div class="rfoot"><div class="pos"><span>Position</span><b id="pos">' +
      (R.idx + 1) + ' von ' + n + '</b></div><div class="slider"><div class="trk"></div><div class="thumb" id="thumb" style="left:' + sliderPos(n) +
      '%"></div><input type="range" id="slider" min="1" max="' + n + '" value="' + (R.idx + 1) +
      '"></div><div class="acts" id="acts">' + actionsInner() + '</div></div>';
  } else {
    h += '<div class="rbody" id="rbody">' + RV.map(function (v, i) {
      var note = S.notes[nkey(R.b, R.c, v.n)];
      return '<div class="vp' + (R.sel === i ? ' sel' : '') + (isMarked({b:R.b, c:R.c, v:v.n}) ? ' mk' : '') + '" data-a="vsel" data-i="' + i + '"><span class="vn">' + v.n +
        '</span><span>' + esc(v.t) + '</span>' + (note ? '<div class="vnote">' + esc(note) + '</div>' : '') + '</div>';
    }).join('') + '</div>';
    if (R.sel != null) h += '<div class="rfoot"><div class="acts single" id="acts" style="margin-top:calc(11 * var(--u))">' + actionsInner() + '</div></div>';
  }
  if (R.menu === 'font') h += '<div class="pbg" data-a="rMenuClose" style="position:absolute;left:0;right:0;top:calc(71 * var(--u));bottom:0;z-index:7"></div>' + fontPop();
  el.innerHTML = h;
  var rb = $('#rbody');
  if (rb) {
    if (scrollSel) { var s = rb.querySelector('.vp.sel'); if (s) s.scrollIntoView(); }
    else rb.scrollTop = keep;
  }
}
function updateFocused() {
  var n = RV.length;
  $('#rbody').innerHTML = focusVerse();
  $('#rbody').scrollTop = 0;
  $('#pos').textContent = (R.idx + 1) + ' von ' + n;
  $('#prog').style.width = Math.round((R.idx + 1) / n * 100) + '%';
  var sl = $('#slider'); if (sl) sl.value = R.idx + 1;
  var th = $('#thumb'); if (th) th.style.left = sliderPos(n) + '%';
  $('#acts').innerHTML = actionsInner();
}
function fontPop() {
  return '<div class="pop fontpop"><span class="lbl">Übersetzung</span><div class="g3 tr">' + SLOTS.map(function (x) {
    return '<button data-a="rTrans" data-id="' + x.id + '" class="' + (S.bible === x.id ? 'on' : '') + '">' + x.short + '</button>';
  }).join('') + '</div><span class="lbl f2">Schriftart</span><div class="g3">' + FONTS.map(function (f) {
    return '<button data-a="setFont" data-id="' + f.id + '" class="' + (S.font === f.id ? 'on' : '') + '" style="font-family:' + f.css + '">' + f.name + '</button>';
  }).join('') + '</div><span class="lbl f2">Schriftgrösse</span><div class="g4">' + Object.keys(SIZES).map(function (k) {
    return '<button data-a="setSize" data-id="' + k + '" class="' + (S.size === k ? 'on' : '') + '">' + k + '</button>';
  }).join('') + '</div><span class="lbl f2">Anzeige</span><button class="togg ' + (S.focused ? 'on dark' : '') +
    '" data-a="toggleFocus"><span>Focused Mode</span><span>' + (S.focused ? 'AN' : 'AUS') + '</span></button></div>';
}
function bookPanel() {
  var h = '<div class="bp">';
  if (R.bsel == null) {
    h += '<div class="bphead"><span>Bibel</span><button data-a="rBooksClose">' + ic('x') + '</button></div><div class="bpbody">';
    [['Altes Testament', 0, 39], ['Neues Testament', 39, 66]].forEach(function (s) {
      h += '<span class="lbl">' + s[0] + '</span><div class="gbooks">';
      for (var i = s[1]; i < s[2]; i++) h += '<button data-a="bookPick" data-b="' + i + '"><b>' + esc(bname(i)) + '</b><small>' + nch(i) + ' Kap.</small></button>';
      h += '</div>';
    });
    h += '</div>';
  } else {
    h += '<div class="bphead"><button data-a="bookBack">' + ic('left') + '</button><span>' + esc(bname(R.bsel)) +
      '</span><button data-a="rBooksClose">' + ic('x') + '</button></div><div class="bpbody"><div class="gchap">';
    for (var c = 1; c <= nch(R.bsel); c++) h += '<button data-a="chapPick" data-c="' + c + '">' + c + '</button>';
    h += '</div></div>';
  }
  return h + '</div>';
}
function switchBible(id) {
  var n = RV[R.idx] ? RV[R.idx].n : 1, sn = (R.sel != null && RV[R.sel]) ? RV[R.sel].n : null;
  R.menu = null;
  if (id === S.bible) { renderReader(); return; }
  S.bible = id; save();
  if (R.c > nch(R.b)) R.c = nch(R.b);
  RV = chapter(S.bible, R.b, R.c);
  var find = function (x) { for (var i = 0; i < RV.length; i++) if (RV[i].n === x) return i; return -1; };
  var k = find(n); R.idx = k >= 0 ? k : Math.max(0, Math.min(R.idx, RV.length - 1));
  if (sn != null) { k = find(sn); R.sel = k >= 0 ? k : null; }
  recordRead(R.b, R.c);
  renderReader();
}
function gotoChapter(b, c, last) {
  R.b = b; R.c = c; R.sel = null; R.menu = null;
  RV = chapter(S.bible, b, c);
  R.idx = last ? Math.max(0, RV.length - 1) : 0;
  recordRead(b, c);
  renderReader();
}
function nextVerse() {
  if (R.idx < RV.length - 1) { R.idx++; updateFocused(); return; }
  if (R.c < nch(R.b)) gotoChapter(R.b, R.c + 1, false);
  else if (R.b < 65) gotoChapter(R.b + 1, 1, false);
}
function prevVerse() {
  if (R.idx > 0) { R.idx--; updateFocused(); return; }
  if (R.c > 1) gotoChapter(R.b, R.c - 1, true);
  else if (R.b > 0) gotoChapter(R.b - 1, nch(R.b - 1), true);
}

/* ---------- Kommentar / Merken / Hinzufügen ---------- */
function commentDialog() {
  var t = target(); if (!t) return;
  var cur = S.notes[nkey(t.b, t.c, t.v)] || '';
  modal('<div class="mbox"><h3>' + esc(fmtRef(t.b, t.c, t.v)) + '</h3><textarea class="field" id="cmt" placeholder="Kommentar …">' + esc(cur) +
    '</textarea><div class="btns"><button class="dark" data-a="cmtSave">Speichern</button>' +
    (cur ? '<button class="c" data-a="cmtDel">Löschen</button>' : '') + '<button class="c" data-a="closeModal">Abbrechen</button></div></div>');
}
function toggleMark() {
  var t = target(); if (!t) return;
  var found = -1;
  S.marks.forEach(function (m, i) { if (m.b === t.b && m.c === t.c && m.v === t.v && m.bid === S.bible) found = i; });
  if (found >= 0) { S.marks.splice(found, 1); toast('Merkung entfernt'); }
  else { S.marks.push({b:t.b, c:t.c, v:t.v, bid:S.bible}); toast('Gemerkt'); }
  save();
  var a = $('#acts'); if (a) a.innerHTML = actionsInner();
  var rb = $('#rbody');
  if (S.focused && rb && RV[R.idx]) { var st = rb.scrollTop; rb.innerHTML = focusVerse(); rb.scrollTop = st; }
}
var addRef = null;
function addDialog(ref) {
  addRef = ref;
  var h = '<div class="mbox"><h3>Zur Sammlung hinzufügen</h3><div class="btns">';
  S.andachten.forEach(function (a) {
    h += '<button data-a="addPick" data-id="' + a.id + '">' + ic('book') + '<span class="tt">' + esc(a.title || 'Ohne Titel') + '</span></button>';
  });
  h += '<button data-a="addNew">' + ic('plus') + 'Neue Sammlung</button><button class="c" data-a="closeModal">Abbrechen</button></div></div>';
  modal(h);
}
function addVerseTo(a, ref) {
  ref = ref || addRef; if (!ref) return;
  var bid = ref.bid || S.bible;
  if (a.verses.some(function (x) { return x.b === ref.b && x.c === ref.c && x.v === ref.v && x.bid === bid; })) { toast('Schon in dieser Sammlung'); return; }
  a.verses.push({b:ref.b, c:ref.c, v:ref.v, bid:bid, note:S.notes[nkey(ref.b, ref.c, ref.v)] || ''});
  save();
  toast('Zur Sammlung hinzugefügt');
}
function newAndacht() {
  var a = {id:'a' + Date.now(), title:'', text:'', notes:'', verses:[]};
  S.andachten.unshift(a); save();
  return a;
}
function findAndacht(id) {
  for (var i = 0; i < S.andachten.length; i++) if (S.andachten[i].id === id) return S.andachten[i];
  return null;
}

/* ---------- Andacht ---------- */
var A = {id:null, edit:false};
function openAndacht(id, edit) {
  A = {id:id, edit:!!edit};
  showOv('andacht');
  renderAndacht();
}
function renderAndacht() {
  var a = findAndacht(A.id), el = $('#andacht');
  if (!a) { hideOv('andacht'); return; }
  var h;
  var close = '<button class="b-close" data-a="aClose">' + ic('x', 'l') + 'Schließen</button>';
  var verseBtn = a.verses.length ? '<button class="btn-v" data-a="aRead">' + ic('play') + '<span class="cap">Verse lesen</span></button>' : '';
  if (!A.edit) {
    h = '<div class="bar">' + close + '<span class="lbl state">Privat</span>' +
      '<button class="b-main dark" data-a="aEdit">Bearbeiten</button></div><div class="scroll view"><span class="lbl a">Sammlung</span><h2>' +
      esc(a.title || 'Ohne Titel') + '</h2><span class="lbl by">Von ' + esc(S.name) + '</span>' +
      (a.text ? '<p class="txt">' + esc(a.text) + '</p>' : '') + (a.notes ? '<p class="txt">' + esc(a.notes) + '</p>' : '') +
      verseBtn + '</div>';
  } else {
    var vlist = '';
    a.verses.forEach(function (v, i) {
      vlist += '<div class="vitem"><div class="vh"><span>' + esc(fmtRef(v.b, v.c, v.v, v.bid)) + '</span><button data-a="aRemV" data-i="' + i +
        '" aria-label="Entfernen">' + ic('x') + '</button></div><textarea data-note="' + i + '" placeholder="Notiz zum Vers …">' + esc(v.note || '') + '</textarea></div>';
    });
    h = '<div class="bar">' + close + '<span class="lbl state">Privat</span>' +
      '<button class="b-main dark" data-a="aDone">Fertig</button></div><div class="scroll edit"><span class="lbl a">Sammlung</span>' +
      '<input class="field t" id="aTitle" placeholder="Titel" value="' + esc(a.title) + '">' +
      '<textarea class="field f1" id="aText" placeholder="Beschreibung der Sammlung …">' + esc(a.text) + '</textarea>' +
      '<textarea class="field f2" id="aNotes" placeholder="Notizen …">' + esc(a.notes) + '</textarea>' + verseBtn +
      '<button class="btn-del" data-a="aDel">' + ic('trash', 'l') + 'Löschen</button>' +
      (vlist ? '<div class="vl"><span class="lbl">Verse</span>' + vlist + '</div>' : '') + '</div>';
  }
  el.innerHTML = h;
  var f1 = $('#aText'); if (f1) f1.scrollTop = 0;
}

/* ---------- Verse lesen (Stepper) ---------- */
var ST = {id:null, i:0};
function openStepper(id) {
  var a = findAndacht(id);
  if (!a || !a.verses.length) { toast('Keine Verse in dieser Sammlung'); return; }
  ST = {id:id, i:0};
  showOv('stepper');
  renderStepper();
}
function renderStepper() {
  var a = findAndacht(ST.id), el = $('#stepper');
  if (!a || !a.verses.length) { hideOv('stepper'); return; }
  var n = a.verses.length, v = a.verses[ST.i];
  var got = verseText(v.bid, v.b, v.c, v.v) ? {t:verseText(v.bid, v.b, v.c, v.v), bid:v.bid} : anyText(v.b, v.c, v.v, v.bid);
  el.innerHTML = '<div class="bar"><button class="b-close" data-a="stClose">' + ic('x', 'l') + 'Fertig</button><span class="lbl mid">' + esc(a.title || 'Sammlung') + '</span></div>' +
    '<div class="prog"><i style="width:' + Math.round((ST.i + 1) / n * 100) + '%"></i></div>' +
    '<div class="scroll st" style="padding:0"><span class="lbl r">' + esc(fmtRef(v.b, v.c, v.v, v.bid).replace(/ (\d+)[,:](\d+)$/, ' $1:$2')) + '</span><div class="stext">' +
    (got ? '„' + esc(got.t) + '"' : '<span class="muted" style="font-family:var(--sans);font-size:calc(14 * var(--u))">Text nicht eingebaut.</span>') +
    '</div>' + (v.note ? '<div class="snote">' + esc(v.note) + '</div>' : '') + '</div>' +
    '<div class="sfoot"><div class="nav2"><button data-a="stPrev"' + (ST.i === 0 ? ' disabled' : '') + '>' + ic('left') + '<span class="cap">Zurück</span></button>' +
    '<button data-a="stNext"' + (ST.i === n - 1 ? ' disabled' : '') + '>' + ic('right') + '<span class="cap">Weiter</span></button></div>' +
    '<div class="sinfo"><span class="lbl">' + (ST.i + 1) + ' von ' + n + '</span><button data-a="stRead">' + ic('bookm') + 'Im Kapitel lesen</button></div></div>';
}
function stStep(d) {
  var a = findAndacht(ST.id); if (!a) return;
  var i = ST.i + d;
  if (i < 0 || i >= a.verses.length) return;
  ST.i = i; renderStepper();
}

/* ---------- Profil / Import ---------- */
var pending = null;
function profileDialog() {
  modal('<div class="profmenu"><div class="who"><b>' + esc(S.name) + '</b><span>Version 4 · ' + SLOTS.filter(function (x) { return isFull(x.id); }).length + ' von ' + SLOTS.length + ' Bibeln vollständig</span></div>' +
    '<button data-a="imgPick">' + ic('camera') + 'Profilbild ändern</button>' +
    '<button data-a="nameEdit">' + ic('pencil') + 'Name ändern</button>' +
    '<button data-a="importBible">' + ic('upload') + 'Bibel importieren</button></div>', true);
}
function slotPicker() {
  var h = '<div class="mbox"><h3>Welche Übersetzung ist das?</h3><p class="muted">Wähle den Platz, auf dem die Bibel gespeichert wird.</p><div class="btns">';
  SLOTS.forEach(function (s) {
    var has = false; try { has = !!(window.Android && Android.hasBible(s.id)); } catch (e) {}
    h += '<button data-a="slotPick" data-id="' + s.id + '"><span style="flex:1">' + esc(s.name) + '</span>' + (has ? '<small>ersetzen</small>' : '') + '</button>';
  });
  modal(h + '<button class="c" data-a="closeModal">Abbrechen</button></div></div>');
}
function handleBibleFile(file) {
  var rd = new FileReader();
  rd.onload = function () {
    var txt = String(rd.result).replace(/^﻿/, '');
    try {
      var d = toDense(JSON.parse(txt));
      if (!d || d.length !== 66) throw new Error('66');
      pending = txt;
      slotPicker();
    } catch (e) {
      toast('Datei nicht lesbar: erwartet 66 Bücher (1. Mose bis Offenbarung) als JSON');
    }
  };
  rd.onerror = function () { toast('Datei konnte nicht gelesen werden'); };
  rd.readAsText(file);
}
function handleImage(file) {
  var url = URL.createObjectURL(file), img = new Image();
  img.onload = function () {
    var s = Math.min(img.width, img.height), cv = document.createElement('canvas');
    cv.width = cv.height = 112;
    var cx = cv.getContext('2d');
    cx.drawImage(img, (img.width - s) / 2, (img.height - s) / 2, s, s, 0, 0, 112, 112);
    S.img = cv.toDataURL('image/jpeg', 0.8); save();
    URL.revokeObjectURL(url); renderMain();
  };
  img.onerror = function () { toast('Bild konnte nicht gelesen werden'); };
  img.src = url;
}

/* ---------- Aktionen ---------- */
var menuCtx = null;
function tileMenu(el) {
  var i = parseInt(el.getAttribute('data-i'), 10), p = S.marks[i];
  if (!p) return;
  menuCtx = {i:i};
  var r = el.getBoundingClientRect(), u = window.innerWidth / 369;
  var left = Math.min(r.left, window.innerWidth - 246.5 * u - 4);
  var top = Math.max(4, Math.min(r.top - 4 * u, window.innerHeight - 236 * u - 8));
  modal('<div class="ctxmenu" style="left:' + left + 'px;top:' + top + 'px">' +
    '<button data-a="tileOpen">In der Bibel öffnen</button>' +
    '<button data-a="tilePin">' + (p.pin ? 'Lösen' : 'Oben anheften') + '</button>' +
    '<button data-a="tileColl">Zur Sammlung hinzufügen</button>' +
    '<button data-a="tileDel">Vers entfernen</button></div>', true);
}
function showPinCard(i) {
  var p = S.marks[i]; if (!p) return;
  card = {kind:'marks', b:p.b, c:p.c, v:p.v, bid:p.bid};
  renderMain();
}
function openFromList(i) {
  var p = S.marks[i]; if (!p) return;
  openReader(p.b, p.c, p.v, p.bid);
}

function act(a, d, el) {
  var i, x;
  switch (a) {
    case 'tab':
      if (d.t === 'start' && tab === 'start' && !stack.length) {
        card = null; startPanel = null; searchActive = true; renderMain();
        x = $('#q'); if (x) x.focus();
        break;
      }
      setTab(d.t); break;
    case 'profile': profileDialog(); break;
    case 'closeModal': closeModal(); break;
    case 'trans': startPanel = startPanel === 'trans' ? null : 'trans'; renderMain(); break;
    case 'setBible': S.bible = d.id; save(); startPanel = null; renderMain(); break;
    case 'random': startPanel = null; card = randomRef(card); renderMain(); break;
    case 'votd': card = votdRef(); renderMain(); break;
    case 'closeCard': card = null; renderMain(); break;
    case 'openVerse': card = null; openReader(+d.b, +d.c, +d.v, d.id || null); break;
    case 'openCh': openReader(+d.b, +d.c, 0, d.id || null); break;
    case 'sugg': searchVal = ''; searchActive = false; openReader(+d.b, +d.c, +d.v); break;
    case 'clearHist': S.history = []; save(); renderMain(); break;
    case 'mic':
      searchActive = true; renderMain();
      x = $('#q'); if (x) { x.focus(); }
      break;
    case 'tile':
      if (lpFired) { lpFired = false; return; }
      showPinCard(+d.i); break;
    case 'tileOpen': closeModal(); if (menuCtx) openFromList(menuCtx.i); break;
    case 'tilePin':
      closeModal();
      if (menuCtx && S.marks[menuCtx.i]) {
        x = S.marks[menuCtx.i]; x.pin = !x.pin; save(); renderMain(); toast(x.pin ? 'Oben angeheftet' : 'Gelöst');
      }
      break;
    case 'tileColl':
      closeModal();
      if (menuCtx && S.marks[menuCtx.i]) { x = S.marks[menuCtx.i]; addDialog({b:x.b, c:x.c, v:x.v, bid:x.bid}); }
      break;
    case 'tileDel':
      closeModal();
      if (menuCtx) { S.marks.splice(menuCtx.i, 1); save(); renderMain(); toast('Entfernt'); }
      break;
    /* Leser */
    case 'rClose': hideOv('reader'); renderMain(); break;
    case 'rBooks': R.menu = R.menu === 'books' ? null : 'books'; R.bsel = null; renderReader(); break;
    case 'rBooksClose': R.menu = null; R.bsel = null; renderReader(); break;
    case 'bookPick': R.bsel = +d.b; renderReader(); break;
    case 'bookBack': R.bsel = null; renderReader(); break;
    case 'chapPick': gotoChapter(R.bsel, +d.c, false); break;
    case 'rFont': R.menu = R.menu === 'font' ? null : 'font'; renderReader(); break;
    case 'rMenuClose': R.menu = null; renderReader(); break;
    case 'setFont': S.font = d.id; save(); renderReader(); break;
    case 'setSize': S.size = d.id; save(); renderReader(); break;
    case 'toggleFocus': S.focused = !S.focused; if (S.focused && R.sel != null) R.idx = R.sel; save(); renderReader(); break;
    case 'vsel': i = +d.i; R.sel = R.sel === i ? null : i; renderReader(); break;
    case 'rComment': commentDialog(); break;
    case 'cmtSave':
      x = target();
      if (x) {
        var val = $('#cmt').value.trim(), k = nkey(x.b, x.c, x.v);
        if (val) S.notes[k] = val; else delete S.notes[k];
        save();
      }
      closeModal(); renderReader(); break;
    case 'cmtDel':
      x = target(); if (x) { delete S.notes[nkey(x.b, x.c, x.v)]; save(); }
      closeModal(); renderReader(); break;
    case 'rMark': toggleMark(); if (!S.focused) renderReader(); break;
    case 'rAdd': x = target(); if (!x) break; addDialog({b:x.b, c:x.c, v:x.v, bid:S.bible}); break;
    case 'rTrans': switchBible(d.id); break;
    case 'addPick': x = findAndacht(d.id); closeModal(); if (x) addVerseTo(x); break;
    case 'addNew':
      modal('<div class="mbox"><h3>Neue Sammlung</h3><input class="field" id="newTitle" placeholder="Thema, z. B. Vertrauen"><div class="btns">' +
        '<button class="dark" data-a="addNewOk">Anlegen</button><button class="c" data-a="closeModal">Abbrechen</button></div></div>');
      break;
    case 'addNewOk':
      x = newAndacht(); x.title = ($('#newTitle').value || '').trim(); addVerseTo(x); closeModal();
      break;
    /* Andachten */
    case 'newAndacht': x = newAndacht(); openAndacht(x.id, true); break;
    case 'andachtOpen': openAndacht(d.id, false); break;
    case 'aClose': hideOv('andacht'); renderMain(); break;
    case 'aEdit': A.edit = true; renderAndacht(); break;
    case 'aDone': A.edit = false; save(); renderAndacht(); break;
    case 'aRead': openStepper(A.id); break;
    case 'aRemV': x = findAndacht(A.id); if (x) { x.verses.splice(+d.i, 1); save(); renderAndacht(); } break;
    case 'aDel':
      modal('<div class="mbox"><h3>Sammlung löschen?</h3><p class="muted">Das kann nicht rückgängig gemacht werden.</p><div class="btns">' +
        '<button class="dark" data-a="aDelOk">Löschen</button><button class="c" data-a="closeModal">Abbrechen</button></div></div>');
      break;
    case 'aDelOk':
      S.andachten = S.andachten.filter(function (z) { return z.id !== A.id; });
      save(); closeModal(); hideOv('andacht'); renderMain(); break;
    /* Stepper */
    case 'stPrev': stStep(-1); break;
    case 'stNext': stStep(1); break;
    case 'stClose': hideOv('stepper'); break;
    case 'stRead':
      x = findAndacht(ST.id);
      if (x) { var v = x.verses[ST.i]; openReader(v.b, v.c, v.v, v.bid); }
      break;
    /* Profil */
    case 'nameEdit':
      modal('<div class="mbox"><h3>Dein Name</h3><input class="field" id="nameIn" value="' + esc(S.name) + '"><div class="btns">' +
        '<button class="dark" data-a="nameSave">Speichern</button><button class="c" data-a="closeModal">Abbrechen</button></div></div>');
      break;
    case 'nameSave': x = $('#nameIn').value.trim(); if (x) { S.name = x; save(); } closeModal(); renderMain(); break;
    case 'imgPick': closeModal(); $('#fileImg').click(); break;
    case 'importBible': closeModal(); $('#fileBible').click(); break;
    case 'slotPick':
      closeModal();
      if (!pending) break;
      var ok = false;
      try { ok = window.Android ? Android.saveBible(d.id, pending) : false; } catch (e) { ok = false; }
      if (!ok && !window.Android) { cache[d.id] = toDense(JSON.parse(pending)); ok = true; }
      else delete cache[d.id];
      pending = null;
      if (ok) { toast('Importiert: ' + slot(d.id).name); if (!stack.length) renderMain(); else if (topOv() === 'reader') renderReader(); }
      else toast('Speichern fehlgeschlagen');
      break;
  }
}

/* ---------- Ereignisse ---------- */
var lpTimer = null, lpFired = false, lpX = 0, lpY = 0;
document.addEventListener('pointerdown', function (e) {
  var t = e.target.closest ? e.target.closest('.tile') : null;
  if (!t) return;
  lpFired = false; lpX = e.clientX; lpY = e.clientY;
  clearTimeout(lpTimer);
  lpTimer = setTimeout(function () { lpFired = true; lpTimer = null; tileMenu(t); }, 550);
});
document.addEventListener('pointermove', function (e) {
  if (lpTimer && (Math.abs(e.clientX - lpX) > 10 || Math.abs(e.clientY - lpY) > 10)) { clearTimeout(lpTimer); lpTimer = null; }
});
['pointerup', 'pointercancel'].forEach(function (ev) {
  document.addEventListener(ev, function () { clearTimeout(lpTimer); lpTimer = null; });
});
document.addEventListener('mousedown', function (e) {
  if (e.target.closest && e.target.closest('.sugg')) e.preventDefault();
});
document.addEventListener('contextmenu', function (e) { e.preventDefault(); });

document.addEventListener('click', function (e) {
  var tg = e.target;
  if (startPanel === 'trans' && tg.closest && !tg.closest('.dd')) { startPanel = null; renderMain(); return; }
  if (tg.id === 'q') {
    if (searchActive) return;
    if (startPanel !== 'history') { startPanel = 'history'; renderMain(); }
    else {
      searchActive = true; renderMain();
      var q = $('#q'); q.focus();
      try { q.setSelectionRange(q.value.length, q.value.length); } catch (x) {}
    }
    return;
  }
  if (topOv() === 'reader' && S.focused && !R.menu && $('#modal').hidden && tg.closest && tg.closest('#rbody') && !tg.closest('[data-a]')) {
    if (e.clientX < window.innerWidth * 0.35) prevVerse(); else nextVerse();
    return;
  }
  var t = tg.closest ? tg.closest('[data-a]') : null;
  if (!t) return;
  act(t.getAttribute('data-a'), {
    t:t.getAttribute('data-t'), id:t.getAttribute('data-id'), b:t.getAttribute('data-b'), c:t.getAttribute('data-c'),
    v:t.getAttribute('data-v'), i:t.getAttribute('data-i'), k:t.getAttribute('data-k')
  }, t);
});

document.addEventListener('keydown', function (e) {
  if (e.target.id === 'q' && (e.key === 'Enter' || e.keyCode === 13)) {
    e.preventDefault();
    var v = e.target.value; e.target.blur();
    doSearch(v);
  }
});
document.addEventListener('input', function (e) {
  var t = e.target, a;
  if (t.id === 'q') { searchVal = t.value; applySugg(); return; }
  if (t.id === 'slider') { R.idx = parseInt(t.value, 10) - 1; updateFocused(); return; }
  if (A.id && (t.id === 'aTitle' || t.id === 'aText' || t.id === 'aNotes' || t.hasAttribute('data-note'))) {
    a = findAndacht(A.id); if (!a) return;
    if (t.id === 'aTitle') a.title = t.value;
    else if (t.id === 'aText') a.text = t.value;
    else if (t.id === 'aNotes') a.notes = t.value;
    else a.verses[+t.getAttribute('data-note')].note = t.value;
    save();
  }
});
document.addEventListener('focusout', function (e) {
  if (e.target.id === 'q' && e.target.isConnected) { searchActive = false; e.target.readOnly = true; }
});
$('#fileBible').addEventListener('change', function (e) {
  var f = e.target.files && e.target.files[0]; e.target.value = '';
  if (f) handleBibleFile(f);
});
$('#fileImg').addEventListener('change', function (e) {
  var f = e.target.files && e.target.files[0]; e.target.value = '';
  if (f) handleImage(f);
});

/* Wischgesten */
var tx = 0, ty = 0, tt = 0;
document.addEventListener('touchstart', function (e) {
  var t = e.touches[0]; tx = t.clientX; ty = t.clientY; tt = Date.now();
}, {passive:true});
document.addEventListener('touchend', function (e) {
  if (!$('#modal').hidden) return;
  var t = e.changedTouches[0], dx = t.clientX - tx, dy = t.clientY - ty, tg = e.target;
  if (Math.abs(dx) < 70 * (window.innerWidth / 369) / 1.3 || Math.abs(dy) > Math.abs(dx) * 0.6 || Date.now() - tt > 900) return;
  if (tg.closest && tg.closest('input,textarea')) return;
  var left = dx < 0, top = topOv();
  if (top === 'reader') {
    if (R.menu) return;
    if (S.focused && RV.length) { if (left) nextVerse(); else prevVerse(); }
    else if (!left) { hideOv('reader'); renderMain(); }
  } else if (top === 'stepper') {
    stStep(left ? 1 : -1);
  } else if (!top && tab === 'start' && left && !card && tg.closest && tg.closest('#body')) {
    openReader(S.last.b, S.last.c);
  }
}, {passive:true});

/* Lautstärketasten: leiser = weiter, lauter = zurück (nur im Leser / bei "Verse lesen") */
window.appVolume = function (d) {
  var top = topOv();
  if (top === 'stepper') { stStep(d); return true; }
  if (top !== 'reader' || R.menu || !$('#modal').hidden) return false;
  if (S.focused && RV.length) { if (d > 0) nextVerse(); else prevVerse(); return true; }
  var rb = $('#rbody');
  if (rb) rb.scrollTop += d * rb.clientHeight * 0.85;
  return true;
};

/* Zurück-Taste von Android */
window.appBack = function () {
  if (!$('#modal').hidden) { closeModal(); return true; }
  var top = topOv();
  if (top) {
    if (top === 'reader' && R.menu) {
      if (R.menu === 'books' && R.bsel != null) R.bsel = null; else R.menu = null;
      renderReader(); return true;
    }
    hideOv(top);
    if (!stack.length) renderMain();
    return true;
  }
  if (card || startPanel) { card = null; startPanel = null; renderMain(); return true; }
  if (tab !== 'start') { setTab('start'); return true; }
  return false;
};

applyReadStyle();
renderMain();
})();
