/* Eingebaute BEISPIEL-Verse (nur zum Ausprobieren).
   Eintrag: [Buch-Index (0 = 1. Mose … 65 = Offenbarung), Kapitel, Vers, Text]
   Vollständige Bibeln importierst du in der App über das Profil-Menü → "Bibel importieren". */
window.SAMPLE = {
  kjv: [
    [0,1,1,"In the beginning God created the heaven and the earth."],
    [5,1,9,"Have not I commanded thee? Be strong and of a good courage; be not afraid, neither be thou dismayed: for the LORD thy God is with thee whithersoever thou goest."],
    [18,23,1,"The LORD is my shepherd; I shall not want."],
    [18,23,2,"He maketh me to lie down in green pastures: he leadeth me beside the still waters."],
    [18,23,3,"He restoreth my soul: he leadeth me in the paths of righteousness for his name's sake."],
    [18,23,4,"Yea, though I walk through the valley of the shadow of death, I will fear no evil: for thou art with me; thy rod and thy staff they comfort me."],
    [18,23,5,"Thou preparest a table before me in the presence of mine enemies: thou anointest my head with oil; my cup runneth over."],
    [18,23,6,"Surely goodness and mercy shall follow me all the days of my life: and I will dwell in the house of the LORD for ever."],
    [18,91,1,"He that dwelleth in the secret place of the most High shall abide under the shadow of the Almighty."],
    [19,3,5,"Trust in the LORD with all thine heart; and lean not unto thine own understanding."],
    [19,3,6,"In all thy ways acknowledge him, and he shall direct thy paths."],
    [19,16,9,"A man's heart deviseth his way: but the LORD directeth his steps."],
    [22,40,31,"But they that wait upon the LORD shall renew their strength; they shall mount up with wings as eagles; they shall run, and not be weary; and they shall walk, and not faint."],
    [22,41,10,"Fear thou not; for I am with thee: be not dismayed; for I am thy God: I will strengthen thee; yea, I will help thee; yea, I will uphold thee with the right hand of my righteousness."],
    [22,55,11,"So shall my word be that goeth forth out of my mouth: it shall not return unto me void, but it shall accomplish that which I please, and it shall prosper in the thing whereto I sent it."],
    [23,29,11,"For I know the thoughts that I think toward you, saith the LORD, thoughts of peace, and not of evil, to give you an expected end."],
    [28,2,25,"And I will restore to you the years that the locust hath eaten, the cankerworm, and the caterpiller, and the palmerworm, my great army which I sent among you."],
    [39,11,28,"Come unto me, all ye that labour and are heavy laden, and I will give you rest."],
    [39,19,26,"But Jesus beheld them, and said unto them, With men this is impossible; but with God all things are possible."],
    [42,3,16,"For God so loved the world, that he gave his only begotten Son, that whosoever believeth in him should not perish, but have everlasting life."],
    [43,1,8,"But ye shall receive power, after that the Holy Ghost is come upon you: and ye shall be witnesses unto me both in Jerusalem, and in all Judaea, and in Samaria, and unto the uttermost part of the earth."],
    [44,8,28,"And we know that all things work together for good to them that love God, to them who are the called according to his purpose."],
    [46,5,17,"Therefore if any man be in Christ, he is a new creature: old things are passed away; behold, all things are become new."],
    [49,4,13,"I can do all things through Christ which strengtheneth me."],
    [57,11,1,"Now faith is the substance of things hoped for, the evidence of things not seen."]
  ],
  luther1912: [
    [0,1,1,"Am Anfang schuf Gott Himmel und Erde."],
    [5,1,9,"Siehe, ich habe dir geboten, daß du getrost und freudig seiest. Laß dir nicht grauen und entsetze dich nicht; denn der HERR, dein Gott, ist mit dir in allem, was du tun wirst."],
    [18,23,1,"Der HERR ist mein Hirte, mir wird nichts mangeln."],
    [18,23,2,"Er weidet mich auf einer grünen Aue und führet mich zum frischen Wasser."],
    [18,23,3,"Er erquicket meine Seele; er führet mich auf rechter Straße um seines Namens willen."],
    [18,23,4,"Und ob ich schon wanderte im finstern Tal, fürchte ich kein Unglück; denn du bist bei mir, dein Stecken und Stab trösten mich."],
    [18,23,5,"Du bereitest vor mir einen Tisch im Angesicht meiner Feinde. Du salbest mein Haupt mit Öl und schenkest mir voll ein."],
    [18,23,6,"Gutes und Barmherzigkeit werden mir folgen mein Leben lang, und ich werde bleiben im Hause des HERRN immerdar."],
    [19,3,5,"Verlaß dich auf den HERRN von ganzem Herzen, und verlaß dich nicht auf deinen Verstand,"],
    [19,3,6,"sondern gedenke an ihn in allen deinen Wegen, so wird er dich recht führen."],
    [22,40,31,"aber die auf den HERRN harren, kriegen neue Kraft, daß sie auffahren mit Flügeln wie Adler, daß sie laufen und nicht matt werden, daß sie wandeln und nicht müde werden."],
    [22,41,10,"Fürchte dich nicht, ich bin mit dir; weiche nicht, denn ich bin dein Gott; ich stärke dich, ich helfe dir auch, ich halte dich durch die rechte Hand meiner Gerechtigkeit."],
    [23,29,11,"Denn ich weiß wohl, was ich für Gedanken über euch habe, spricht der HERR: Gedanken des Friedens und nicht des Leides, daß ich euch gebe das Ende, des ihr wartet."],
    [39,11,28,"Kommet her zu mir, alle, die ihr mühselig und beladen seid; ich will euch erquicken."],
    [39,19,26,"Jesus aber sah sie an und sprach zu ihnen: Bei den Menschen ist's unmöglich; aber bei Gott sind alle Dinge möglich."],
    [42,3,16,"Also hat Gott die Welt geliebet, daß er seinen eingeborenen Sohn gab, auf daß alle, die an ihn glauben, nicht verloren werden, sondern das ewige Leben haben."],
    [43,1,8,"aber ihr werdet die Kraft des Heiligen Geistes empfangen, welcher auf euch kommen wird, und werdet meine Zeugen sein zu Jerusalem und in ganz Judäa und Samaria und bis an das Ende der Erde."],
    [44,8,28,"Wir wissen aber, daß denen, die Gott lieben, alle Dinge zum Besten dienen, denen, die nach dem Vorsatz berufen sind."],
    [46,5,17,"Darum, ist jemand in Christo, so ist er eine neue Kreatur; das Alte ist vergangen, siehe, es ist alles neu geworden!"],
    [49,4,13,"Ich vermag alles durch den, der mich mächtig macht, Christus."],
    [57,11,1,"Es ist aber der Glaube eine gewisse Zuversicht des, das man hoffet, und ein Nichtzweifeln an dem, das man nicht siehet."]
  ],
  schlachter: [
    [9,8,1,"Darnach begab es sich, daß David die Philister schlug und sie demütigte. Und David nahm die Zügel der Regierung aus der Hand der Philister."],
    [9,8,2,"Er schlug auch die Moabiter und maß sie mit der Meßschnur; er legte sie auf die Erde und maß zwei volle Schnurlängen ab, um sie zu töten, und eine volle Schnurlänge, um sie am Leben zu lassen. Also wurden die Moabiter David untertan und tributpflichtig gemacht."],
    [19,16,9,"Des Menschen Herz denkt sich einen Weg aus; aber der HERR lenkt seine Schritte."],
    [43,1,8,"sondern ihr werdet Kraft empfangen, wenn der heilige Geist über euch kommt, und werdet Zeugen für mich sein in Jerusalem und in ganz Judäa und Samaria und bis ans Ende der Erde!"],
    [46,5,17,"Darum, ist jemand in Christus, so ist er eine neue Kreatur; das Alte ist vergangen, siehe, es ist alles neu geworden!"]
  ],
  riveduta: [
    [18,91,1,"Chi dimora nel ritiro dell'Altissimo alberga all'ombra dell'Onnipotente."]
  ]
};

/* Kuratierte Liste für „Vers des Tages“ und „Zufälliger Vers“ (Verweise; der Text kommt aus der gewählten Bibel).
   Sobald eine vollständige Bibel importiert ist, wählt „Zufälliger Vers“ aus der ganzen Bibel. */
window.REFS = [
  [0,1,1],[1,14,14],[4,31,6],[5,1,9],[8,16,7],[17,5,25],[18,23,1],[18,27,1],[18,34,8],[18,37,4],[18,46,1],[18,91,1],
  [18,119,105],[18,121,2],[19,3,5],[19,3,6],[19,16,9],[19,18,10],[22,26,3],[22,40,31],[22,41,10],[22,43,2],
  [22,55,11],[22,60,22],[22,66,8],[23,29,11],[24,3,22],[28,2,25],[32,6,8],[39,5,16],[39,6,33],[39,7,7],
  [39,11,28],[39,19,26],[39,28,20],[42,1,1],[42,3,16],[42,8,12],[42,10,10],[42,14,6],[42,14,27],[42,15,5],
  [43,1,8],[44,5,8],[44,8,28],[44,12,2],[45,13,13],[46,5,17],[46,12,9],[47,2,20],[47,5,22],[48,2,8],
  [49,4,6],[49,4,13],[50,3,23],[51,5,16],[54,1,7],[57,11,1],[57,13,8],[58,1,5],[59,5,7],[61,4,19],[65,21,4]
];
